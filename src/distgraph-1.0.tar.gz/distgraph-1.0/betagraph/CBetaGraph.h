#ifndef _CBetaGraph_H_
#define _CBetaGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CBetaGraph CBetaGraph;

struct _CBetaGraph
{
	void (*FP_createChart)(CBetaGraph* pThis);
	void (*FP_writeChartAsJPEG)(CBetaGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CBetaGraph* getBetaGraph(char* modPth, double alpha, double beta);
void CBetaGraph_ctor(CBetaGraph* pThis, char* modPth, double alpha, double beta);
void CBetaGraph_dtor(CBetaGraph* pThis);
void CBetaGraph_createChart(CBetaGraph* pThis);
void CBetaGraph_writeChartAsJPEG(CBetaGraph* pThis, char* fileName);
#endif
