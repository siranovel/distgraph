#include <stdio.h>
#include <assert.h>
#include "JTextTitle.h"
#include "JClassLoader.h"

static jobject doNewTextTitle(JNIEnv* env, jobject loader, jstring text);
jobject newTextTitle(JNIEnv* env, jobject loader, jstring text)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewTextTitle(env, loader, text);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewTextTitle(JNIEnv* env, jobject loader, jstring text)
{
	jvalue argValues[] = {
		[0] = { .l = text},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,TextTitle));
	
	return JClass_NewObjectA(env, clz, "(Ljava/lang/String;)V", argValues);
}
