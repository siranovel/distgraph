#include <stdio.h>
#include <assert.h>
#include "JFunction.h"

static jobject JFunction_doApply(JNIEnv* env, jobject clf, jstring name);
static JFunction _jFunction = {
	.FP_apply = JFunction_doApply,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JFunction_apply(JNIEnv* env, jobject clf, jstring name)
{
	return _jFunction.FP_apply(env, clf, name);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JFunction_doApply(JNIEnv* env, jobject clf, jstring name)
{
	assert(name != 0);
	jvalue argValues[] = {
		[0] = { .l = name},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, clf), "apply", "(Ljava/lang/Object;)Ljava/lang/Object;");
	return JClass_CallObjectMethodA(env, clf, mid, argValues);
}

