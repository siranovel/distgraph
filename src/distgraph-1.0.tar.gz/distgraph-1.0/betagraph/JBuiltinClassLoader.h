#ifndef _JBuiltinClassLoader_H_
#define _JBuiltinClassLoader_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JBuiltinClassLoader JBuiltinClassLoader;

struct _JBuiltinClassLoader
{
	void (*FP_loadModule)(JNIEnv* env, jobject loader, jobject mref);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
void JBuiltinClassLoader_loadModule(JNIEnv* env, jobject loader, jobject mref);
#endif
