#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CConstRGraph.h"

static void usage(char* exeNm);
void constRGraph(CConstRGraph* pThis);
int main(int argc, char* argv[])
{
	double value = 0.0;
	
	if (3 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &value);
	
	CConstRGraph* pThis = getConstRGraph(updModPth, value);
	
	constRGraph(pThis);
	CConstRGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <value> \n", exeNm);
}
void constRGraph(CConstRGraph* pThis)
{
	CConstRGraph_createChart(pThis);
	CConstRGraph_writeChartAsJPEG(pThis, "constRGraph.jpg");
}
