#ifndef _CConstRGraph_H_
#define _CConstRGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CConstRGraph CConstRGraph;

struct _CConstRGraph
{
	void (*FP_createChart)(CConstRGraph* pThis);
	void (*FP_writeChartAsJPEG)(CConstRGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CConstRGraph* getConstRGraph(char* modPth, double value);
void CConstRGraph_ctor(CConstRGraph* pThis, char* modPth, double value);
void CConstRGraph_dtor(CConstRGraph* pThis);
void CConstRGraph_createChart(CConstRGraph* pThis);
void CConstRGraph_writeChartAsJPEG(CConstRGraph* pThis, char* fileName);
#endif
