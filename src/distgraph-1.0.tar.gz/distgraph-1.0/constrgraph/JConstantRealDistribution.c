#include <stdio.h>
#include <assert.h>
#include "JConstantRealDistribution.h"
#include "JClassLoader.h"

static jobject doNewConstantRealDistribution(JNIEnv* env, jobject loader, double value);
static jdouble JConstantRealDistribution_doDensity(JNIEnv* env, jobject constRDistObj, jdouble x);
static jdouble JConstantRealDistribution_doLogDensity(JNIEnv* env, jobject constRDistObj, jdouble x);
static jdouble JConstantRealDistribution_doCumulativeProbability(JNIEnv* env, jobject constRDistObj, jdouble x);
static JConstantRealDistribution _jConstRDist = {
	.FP_density = JConstantRealDistribution_doDensity,
	.FP_logDensity = JConstantRealDistribution_doLogDensity,
	.FP_cumulativeProbability = JConstantRealDistribution_doCumulativeProbability,
};
jobject newConstantRealDistribution(JNIEnv* env, jobject loader, double value)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewConstantRealDistribution(env, loader, value);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JConstantRealDistribution_density(JNIEnv* env, jobject constRDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != constRDistObj);
	return _jConstRDist.FP_density(env, constRDistObj, x);
}
jdouble JConstantRealDistribution_logDensity(JNIEnv* env, jobject constRDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != constRDistObj);
	return _jConstRDist.FP_logDensity(env, constRDistObj, x);
}
jdouble JConstantRealDistribution_cumulativeProbability(JNIEnv* env, jobject constRDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != constRDistObj);
	return _jConstRDist.FP_cumulativeProbability(env, constRDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewConstantRealDistribution(JNIEnv* env, jobject loader, double value)
{
	jvalue argValues[] = {
		[0] = { .d = value},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,CONSTR_DIST));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
static jdouble JConstantRealDistribution_doDensity(JNIEnv* env, jobject constRDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, constRDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, constRDistObj, mid, argValues);
}
static jdouble JConstantRealDistribution_doLogDensity(JNIEnv* env, jobject constRDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, constRDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, constRDistObj, mid, argValues);
}
static jdouble JConstantRealDistribution_doCumulativeProbability(JNIEnv* env, jobject constRDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, constRDistObj), "cumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, constRDistObj, mid, argValues);
}
