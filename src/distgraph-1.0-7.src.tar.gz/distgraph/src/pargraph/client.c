#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CParGraph.h"

static void usage(char* exeNm);
void parGraph(CParGraph* pThis);
int main(int argc, char* argv[])
{
	double scale = 0.0;
	double shape = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &scale);
	sscanf(argv[3], "%lf", &shape);
	
	CParGraph* pThis = getCParGraph(updModPth, scale, shape);
	
	parGraph(pThis);
	CParGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <scale> <shape> \n", exeNm);
}
void parGraph(CParGraph* pThis)
{
	CParGraph_createChart(pThis);
	CParGraph_writeChartAsJPEG(pThis, "parGraph.jpg");
}
