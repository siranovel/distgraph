#include <stdio.h>
#include <assert.h>
#include "JBetaDistribution.h"
#include "JClassLoader.h"


static jobject doNewBetaDistribution(JNIEnv* env, jobject emptyM, double alpha, double beta);
static jdouble JBetaDistribution_doDdensity(JNIEnv* env, jobject beDistObj, jdouble x);
static jdouble JBetaDistribution_doLogDensity(JNIEnv* env, jobject beDistObj, jdouble x);
static JBetaDistribution _jBetaDist = {
	.FP_density = JBetaDistribution_doDdensity,
	.FP_logDensity = JBetaDistribution_doLogDensity,
};
jobject newBetaDistribution(JNIEnv* env, jobject loader, double alpha, double beta)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewBetaDistribution(env, loader, alpha, beta);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JBetaDistribution_density(JNIEnv* env, jobject beDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != beDistObj);
	return _jBetaDist.FP_density(env, beDistObj, x);
}
jdouble JBetaDistribution_logDensity(JNIEnv* env, jobject beDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != beDistObj);
	return _jBetaDist.FP_logDensity(env, beDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewBetaDistribution(JNIEnv* env, jobject loader, double alpha, double beta)
{
	jvalue argValues[] = {
		[0] = { .d = alpha},
		[1] = { .d = beta},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,BE_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JBetaDistribution_doDdensity(JNIEnv* env, jobject beDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, beDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, beDistObj, mid, argValues);
}
static jdouble JBetaDistribution_doLogDensity(JNIEnv* env, jobject beDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, beDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, beDistObj, mid, argValues);
}
