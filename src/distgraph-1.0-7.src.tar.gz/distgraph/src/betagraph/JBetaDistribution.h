#ifndef _JBetaDistribution_H_
#define _JBetaDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JBetaDistribution JBetaDistribution;

struct _JBetaDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject beDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject beDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define BE_DIST "org.apache.commons.math3.distribution.BetaDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newBetaDistribution(JNIEnv* env, jobject loader, double alpha, double beta);
jdouble JBetaDistribution_density(JNIEnv* env, jobject beDistObj, jdouble x);
jdouble JBetaDistribution_logDensity(JNIEnv* env, jobject beDistObj, jdouble x);
#endif
