#ifndef _JCauchyDistribution_H_
#define _JCauchyDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JCauchyDistribution JCauchyDistribution;

struct _JCauchyDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject cauchyDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject cauchyDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define CAUCHY_DIST "org.apache.commons.math3.distribution.CauchyDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newCauchyDistribution(JNIEnv* env, jobject loader, jdouble median, jdouble scale);
jdouble JCauchyDistribution_density(JNIEnv* env, jobject cauchyDistObj, jdouble x);
jdouble JCauchyDistribution_logDensity(JNIEnv* env, jobject cauchyDistObj, jdouble x);

#endif
