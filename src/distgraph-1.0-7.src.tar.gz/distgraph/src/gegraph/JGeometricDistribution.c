#include <stdio.h>
#include <assert.h>
#include "JGeometricDistribution.h"
#include "JClassLoader.h"

static jobject doNewGeometricDistribution(JNIEnv* env, jobject loader, jdouble p);
static jdouble JGeometricDistribution_doProbability(JNIEnv* env, jobject geDistObj, jint x);
static jdouble JGeometricDistribution_doLogProbability(JNIEnv* env, jobject geDistObj, jint x);
static JGeometricDistribution _jGeDist = {
	.FP_probability = JGeometricDistribution_doProbability,
	.FP_logProbability = JGeometricDistribution_doLogProbability,
};
jobject newGeometricDistribution(JNIEnv* env, jobject loader, jdouble p)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewGeometricDistribution(env, loader, p);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JGeometricDistribution_probability(JNIEnv* env, jobject geDistObj, jint x)
{
	assert(0 != env);
	assert(0 != geDistObj);
	return _jGeDist.FP_probability(env, geDistObj, x);
}
jdouble JGeometricDistribution_logProbability(JNIEnv* env, jobject geDistObj, jint x)
{
	assert(0 != env);
	assert(0 != geDistObj);
	return _jGeDist.FP_logProbability(env, geDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewGeometricDistribution(JNIEnv* env, jobject loader, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .d = p},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,GE_DIST));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
static jdouble JGeometricDistribution_doProbability(JNIEnv* env, jobject geDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, geDistObj), "probability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, geDistObj, mid, argValues);
}
static jdouble JGeometricDistribution_doLogProbability(JNIEnv* env, jobject geDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, geDistObj), "logProbability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, geDistObj, mid, argValues);
}
