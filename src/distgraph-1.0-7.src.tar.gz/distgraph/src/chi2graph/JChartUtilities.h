#ifndef _JChartUtilities_H_
#define _JChartUtilities_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JChartUtilities JChartUtilities;

struct _JChartUtilities
{
	void (*FP_writeChartAsJPEG)(JNIEnv* env, jobject loader, jstring name,  jobject chart, int width, int height);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define ChartUtilities         "org.jfree.chart.ChartUtilities"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
void JChartUtilities_writeChartAsJPEG(JNIEnv* env, jobject loader, jstring name,  jobject chart, int width, int height);
#endif
