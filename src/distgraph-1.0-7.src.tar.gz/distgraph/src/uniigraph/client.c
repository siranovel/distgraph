#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CUniIGraph.h"

static void usage(char* exeNm);
static void uniiGraph(CUniIGraph* pThis);
int main(int argc, char* argv[])
{
	int low;
	int up;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &low);
	sscanf(argv[3], "%d", &up);
	
	CUniIGraph* pThis = getUniIGraph(updModPth, low, up);
	
	uniiGraph(pThis);
	CUniIGraph_dtor(pThis);
	
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <low> <up> \n", exeNm);
}
static void uniiGraph(CUniIGraph* pThis)
{
	CUniIGraph_createChart(pThis);
	CUniIGraph_writeChartAsJPEG(pThis, "uniiGraph.jpg");
}
