#include <stdio.h>
#include <assert.h>
#include "JUniformIntegerDistribution.h"
#include "JClassLoader.h"

static jobject doNewUniformIntegerDistribution(JNIEnv* env, jobject loader, jint low, jint up);
static jdouble JUniformIntegerDistribution_doProbability(JNIEnv* env, jobject uniiDistObj, jint x);
static jdouble JUniformIntegerDistribution_doLogProbability(JNIEnv* env, jobject uniiDistObj, jint x);
static JUniformIntegerDistribution _jUniIDist = {
	.FP_probability = JUniformIntegerDistribution_doProbability,
	.FP_logProbability = JUniformIntegerDistribution_doLogProbability,
};
jobject newUniformIntegerDistribution(JNIEnv* env, jobject loader, jint low, jint up)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewUniformIntegerDistribution(env, loader, low, up);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JUniformIntegerDistribution_probability(JNIEnv* env, jobject uniiDistObj, jint x)
{
	assert(0 != env);
	assert(0 != uniiDistObj);
	return _jUniIDist.FP_probability(env, uniiDistObj, x);
}
jdouble JUniformIntegerDistribution_logProbability(JNIEnv* env, jobject uniiDistObj, jint x)
{
	assert(0 != env);
	assert(0 != uniiDistObj);
	return _jUniIDist.FP_logProbability(env, uniiDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewUniformIntegerDistribution(JNIEnv* env, jobject loader, jint low, jint up)
{
	jvalue argValues[] = {
		[0] = { .i = low},
		[1] = { .i = up},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,UNII_DIST));
	
	return JClass_NewObjectA(env, clz, "(II)V", argValues);
}
static jdouble JUniformIntegerDistribution_doProbability(JNIEnv* env, jobject uniiDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, uniiDistObj), "probability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, uniiDistObj, mid, argValues);
}
static jdouble JUniformIntegerDistribution_doLogProbability(JNIEnv* env, jobject uniiDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, uniiDistObj), "logProbability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, uniiDistObj, mid, argValues);
}
