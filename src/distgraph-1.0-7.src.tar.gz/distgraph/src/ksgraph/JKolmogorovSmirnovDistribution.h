#ifndef _JKolmogorovSmirnovDistribution_H_
#define _JKolmogorovSmirnovDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JKolmogorovSmirnovDistribution JKolmogorovSmirnovDistribution;

struct _JKolmogorovSmirnovDistribution
{
	jdouble (*FP_cdf)(JNIEnv* env, jobject ksDistObj, jdouble d);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define KS_DIST "org.apache.commons.math3.distribution.KolmogorovSmirnovDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newKolmogorovSmirnovDistribution(JNIEnv* env, jobject loader, jint n);
jdouble JKolmogorovSmirnovDistribution_cdf(JNIEnv* env, jobject ksDistObj, jdouble d);
#endif
