#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CKsGraph.h"

static void usage(char* exeNm);
void ksGraph(CKsGraph* pThis);
int main(int argc, char* argv[])
{
	double n = 0.0;
	
	if (3 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &n);
	
	CKsGraph* pThis = getKsGraph(updModPth, n);
	
	ksGraph(pThis);
	CKsGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <n> \n", exeNm);
}
void ksGraph(CKsGraph* pThis)
{
	CKsGraph_createChart(pThis);
	CKsGraph_writeChartAsJPEG(pThis, "ksGraph.jpg");
}
