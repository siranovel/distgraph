#ifndef _CLaGraph_H_
#define _CLaGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CLaGraph CLaGraph;

struct _CLaGraph
{
	void (*FP_createChart)(CLaGraph* pThis);
	void (*FP_writeChartAsJPEG)(CLaGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CLaGraph* getLaGraph(char* modPth, double mu, double beta);
void CLaGraph_ctor(CLaGraph* pThis, char* modPth, double mu, double beta);
void CLaGraph_dtor(CLaGraph* pThis);
void CLaGraph_createChart(CLaGraph* pThis);
void CLaGraph_writeChartAsJPEG(CLaGraph* pThis, char* fileName);
#endif
