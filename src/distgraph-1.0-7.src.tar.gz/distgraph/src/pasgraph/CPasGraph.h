#ifndef _CPasGraph_H_
#define _CPasGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CPasGraph CPasGraph;

struct _CPasGraph
{
	void (*FP_createChart)(CPasGraph* pThis);
	void (*FP_writeChartAsJPEG)(CPasGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CPasGraph* getPasGraph(char* modPth, int r, double p);
void CPasGraph_ctor(CPasGraph* pThis, char* modPth, int r, double p);
void CPasGraph_dtor(CPasGraph* pThis);
void CPasGraph_createChart(CPasGraph* pThis);
void CPasGraph_writeChartAsJPEG(CPasGraph* pThis, char* fileName);

#endif
