#include <stdio.h>
#include <assert.h>
#include "JParetoDistribution.h"
#include "JClassLoader.h"


static jobject doNewParetoDistribution(JNIEnv* env, jobject loader, jdouble scale, jdouble shape);
static jdouble JParetoDistribution_doDensity(JNIEnv* env, jobject parDistObj, jdouble x);
static jdouble JParetoDistribution_doLogDensity(JNIEnv* env, jobject parDistObj, jdouble x);
static JParetoDistribution _jParDist = {
	.FP_density = JParetoDistribution_doDensity,
	.FP_logDensity = JParetoDistribution_doLogDensity,
};
jobject newParetoDistribution(JNIEnv* env, jobject loader, jdouble scale, jdouble shape)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewParetoDistribution(env, loader, scale, shape);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JParetoDistribution_density(JNIEnv* env, jobject parDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != parDistObj);
	return _jParDist.FP_density(env, parDistObj, x);
}
jdouble JParetoDistribution_logDensity(JNIEnv* env, jobject parDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != parDistObj);
	return _jParDist.FP_logDensity(env, parDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewParetoDistribution(JNIEnv* env, jobject loader, jdouble scale, jdouble shape)
{
	jvalue argValues[] = {
		[0] = { .d = scale},
		[1] = { .d = shape},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,PAR_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JParetoDistribution_doDensity(JNIEnv* env, jobject parDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, parDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, parDistObj, mid, argValues);
}
static jdouble JParetoDistribution_doLogDensity(JNIEnv* env, jobject parDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, parDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, parDistObj, mid, argValues);
}

