#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CGeGraph.h"

static void usage(char* exeNm);
static void geGraph(CGeGraph* pThis);
int main(int argc, char* argv[])
{
	double p;
	
	if (3 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &p);
	
	CGeGraph* pThis = getGeGraph(updModPth, p);
	
	geGraph(pThis);
	CGeGraph_dtor(pThis);
	
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <p> \n", exeNm);
}
static void geGraph(CGeGraph* pThis)
{
	CGeGraph_createChart(pThis);
	CGeGraph_writeChartAsJPEG(pThis, "geGraph.jpg");
}
