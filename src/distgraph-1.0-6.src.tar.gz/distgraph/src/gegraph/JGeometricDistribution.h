#ifndef _JGeometricDistribution_H_
#define _JGeometricDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JGeometricDistribution JGeometricDistribution;

struct _JGeometricDistribution
{
	jdouble (*FP_probability)(JNIEnv* env, jobject geDistObj, jint x);
	jdouble (*FP_logProbability)(JNIEnv* env, jobject geDistObj, jint x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define GE_DIST "org.apache.commons.math3.distribution.GeometricDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newGeometricDistribution(JNIEnv* env, jobject loader, jdouble p);
jdouble JGeometricDistribution_probability(JNIEnv* env, jobject geDistObj, jint x);
jdouble JGeometricDistribution_logProbability(JNIEnv* env, jobject geDistObj, jint x);

#endif
