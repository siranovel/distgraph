#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "CCauchyGraph.h"

#include "JPaths.h"
#include "JModuleFinder.h"
#include "JSet.h"
#include "JIterator.h"
#include "JModuleReference.h"
#include "JModuleDescriptor.h"
#include "JModuleLayer.h"
#include "JConfiguration.h"
#include "JModuleLoaderMap.h"
#include "JResolvedModule.h"
#include "JFunction.h"
#include "JBootLoader.h"
#include "JBuiltinClassLoader.h"
#include "JClassLoader.h"
#include "JCauchyDistribution.h"

#include "JChartUtilities.h"
#include "JXYSeries.h"
#include "JXYSeriesCollection.h"
#include "JChartFactory.h"
#include "JJFreeChart.h"
#include "JPlot.h"
#include "JValueAxis.h"
#include "JTextTitle.h"

static double _median = 0.0;
static double _scale = 0.0;
static double _from = 0.0;
static double _to = 0.0;
static JavaVM* _vm = 0;
static JNIEnv* _env = 0;
static jobject _loader1 = 0;
static jobject _loader2 = 0;
static jobject _cauchyDistObj = 0;
static jobject _chart = 0;
static void CCauchyGraph_doCreateChart(CCauchyGraph* pThis);
static jobject createDataSet(JNIEnv* env);
static void CCauchyGraph_doWriteChartAsJPEG(CCauchyGraph* pThis, char* fileName);
static void init();
static void end();
static void updModPth(char* modPth);
static void loadModules(JNIEnv* env, jobject cf, jobject clf);

static CCauchyGraph _cCauchyGraph = {
	.FP_createChart = CCauchyGraph_doCreateChart,
	.FP_writeChartAsJPEG = CCauchyGraph_doWriteChartAsJPEG,
};
CCauchyGraph* getCauchyGraph(char* modPth, double median, double scale)
{
	CCauchyGraph_ctor(&_cCauchyGraph, modPth, median, scale);
	return &_cCauchyGraph;
}
void CCauchyGraph_ctor(CCauchyGraph* pThis, char* modPth, double median, double scale)
{
	init();
	updModPth(modPth);
	_median = median;
	_scale = scale;
	_from = -10 + _median;
	_to = 10 + _median;
	_cauchyDistObj = newCauchyDistribution(_env, _loader1, median, scale);
	// ���ܸ줬ʸ���������ʤ��ơ���
	JChartFactory_setChartTheme(_env, _loader2);
}
void CCauchyGraph_dtor(CCauchyGraph* pThis)
{
	end();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CCauchyGraph_createChart(CCauchyGraph* pThis)
{
	assert(pThis != 0);
	pThis->FP_createChart(pThis);
}
void CCauchyGraph_writeChartAsJPEG(CCauchyGraph* pThis, char* fileName)
{
	assert(pThis != 0);
	assert(_chart != 0);
	pThis->FP_writeChartAsJPEG(pThis, fileName);
}
/**************************************/
/* �����¹���                         */
/**************************************/
static void CCauchyGraph_doCreateChart(CCauchyGraph* pThis)
{
	jobject dataset = createDataSet(_env);
	jobject title = JClass_StringNew(_env, "��������ʬ�ۤΥ����");
	jobject categoryAxisLabel = JClass_StringNew(_env, "x");
	jobject valueAxisLabel = JClass_StringNew(_env, "��Ψ");
	
	char subTitle[64];
	sprintf(subTitle, "(median=%lf scale=%lf)", _median, _scale);
	_chart = JChartFactory_createXYLineChart(_env, _loader2, title, categoryAxisLabel, valueAxisLabel, dataset);
	JJFreeChart_addSubtitle(_env, _chart, newTextTitle(_env, _loader2, JClass_StringNew(_env, subTitle)));
	jobject plot = JJFreeChart_getXYPlot(_env, _chart);    // XYPlot
	
	/*--- �ļ� ---*/
	jobject rangeAumAxis = JPloat_getRangeAxis(_env, plot);   // NumberAxis
	JValueAxis_setLowerBound(_env, rangeAumAxis, 0.0);
	/*--- ���� ---*/
	jobject domainAxis = JPloat_getDomainAxis(_env, plot);
	JValueAxis_setLowerBound(_env, domainAxis, _from);
	JValueAxis_setUpperBound(_env, domainAxis, _to);
}
static jobject createDataSet(JNIEnv* env)
{
	double x;
	jobject p = newXYSeries(env, _loader2, JClass_StringNew(_env, "P"));
	jobject series = newXYSeriesCollection(env, _loader2);
	
	for (x = _from; x <= _to; x += DT) {
		JXYSeries_add(env, p, x, JCauchyDistribution_density(_env, _cauchyDistObj, x));
	}
	
	JXYSeriesCollection_addSeries(env, series, p);
	return series;
}
static void CCauchyGraph_doWriteChartAsJPEG(CCauchyGraph* pThis, char* fileName)
{
	JChartUtilities_writeChartAsJPEG(_env, _loader2, JClass_StringNew(_env, fileName), _chart, 800, 500);
}


static JavaVMOption jvmOpts[] = {
	{.optionString = "-XX:+UnlockExperimentalVMOptions", .extraInfo=NULL}
	,{.optionString = "-XX:+EnableJVMCI", .extraInfo=NULL}
	
};
static JavaVMInitArgs vm_args = {
	.version = JNI_VERSION_1_8,
	.nOptions = NSIZE(jvmOpts),
	.options = jvmOpts
};
static void init()
{
	JNI_CreateJavaVM(&_vm, (void **)&_env, (void *)&vm_args);
	
}
static void end()
{
	assert(_vm != NULL);
	(*_vm)->DestroyJavaVM(_vm);
}
static void updModPth(char* modPth)
{
	jobject jmodPath = JPaths_get(_env, modPth);
	jobject mfinder = JModuleFinder_of(_env, jmodPath);
	jobject refs = JModuleFinder_findAll(_env, mfinder);
	jobject iteObj = JSet_iterator(_env, refs);
	
	jobject roots = newSet(_env);
	while(JNI_TRUE == JIterator_hasNext(_env, iteObj)) {
		jobject mref = JIterator_next(_env, iteObj);          // ModuleReference
		jobject mdesc = JModuleReference_descriptor(_env, mref); // ModuleDescriptor
		jstring jdescName = JModuleDescriptor_name(_env, mdesc);
		
		JSet_add(_env, roots, jdescName);
	}
	/*
     *    ModuleFinder finder = ModuleFinder.of(dir1, dir2, dir3);
	 *    ModuleLayer bootLayer = ModuleLayer.boot();
     *    Configuration parent = bootLayer.configuration();
     *    Configuration cf = parent.resolve(finder, ModuleFinder.of(new Path[0]), Set.of("myapp"));
	 *    Function<String, ClassLoader> clf = ModuleLoaderMap.mappingFunction(cf);
     *    ModuleBootstrap.loadModules(cf, clf);
     *        for (ResolvedModule resolvedModule : cf.modules()) {
     *            ModuleReference mref = resolvedModule.reference();
     *            String name = resolvedModule.name();
     *            ClassLoader loader = clf.apply(name);
     *            if (loader == null) {
     *               // skip java.base as it is already loaded
     *               if (!name.equals(JAVA_BASE)) {
     *                   BootLoader.loadModule(mref);
     *               }
     *            } else if (loader instanceof BuiltinClassLoader) {
     *                ((BuiltinClassLoader) loader).loadModule(mref);
     *            }
     *        }
	 */
	jobject bootLayer = JModuleLayer_boot(_env);
	jobject parent = JModuleLayer_configuration(_env, bootLayer);
	jobject cf = JConfiguration_resolveAndBind(_env, parent, mfinder, JModuleFinder_of(_env, 0), roots);
	jobject clf = JModuleLoaderMap_mappingFunction(_env, cf);
	
	loadModules(_env, cf, clf);
	jobject emptyM = JModuleLayer_defineModules(_env, bootLayer, cf, clf);
	_loader1 = JModuleLayer_findLoader(_env, emptyM, JClass_StringNew(_env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	
	_loader2 = JModuleLayer_findLoader(_env, emptyM, JClass_StringNew(_env,"jfreechart"));  // ClassLoader jdbc = emptyM.findLoader("jfreechart")
}
static void loadModules(JNIEnv* env, jobject cf, jobject clf)
{
	jobject reslvedMs = JConfiguration_modules(env, cf);
	jobject iteObj = JSet_iterator(env, reslvedMs);

	while(JNI_TRUE == JIterator_hasNext(env, iteObj)) {
		jobject resolvedModule = JIterator_next(env, iteObj);          // ResolvedModule
		jobject mref = JResolvedModule_reference(env, resolvedModule); // ModuleReference
		jstring name = JResolvedModule_name(env, resolvedModule);
		jobject loader = JFunction_apply(env, clf, name);

		if (0 == loader) {
			const char* _name = JClass_GetStringUTFChars(env, name);
			
			if (0 != strcmp("java.base", _name)) {
				JBootLoader_loadModule(env, mref);
			}
		} else if (JNI_TRUE == JClass_IsInstanceOf(env, loader, JClass_FindClass(env, "jdk/internal/loader/BuiltinClassLoader"))) {
			JBuiltinClassLoader_loadModule(env, loader, mref);
		}
	}
}
