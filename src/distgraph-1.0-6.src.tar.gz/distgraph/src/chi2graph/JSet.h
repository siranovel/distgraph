#ifndef _JSet_H_
#define _JSet_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JSet JSet;

struct _JSet
{
	jobject (*FP_iterator)(JNIEnv* env, jobject setObj);
	void (*FP_add)(JNIEnv* env, jobject set, jobject e);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newSet(JNIEnv* env);
jobject JSet_iterator(JNIEnv* env, jobject setObj);
void JSet_add(JNIEnv* env, jobject set, jobject e);
#endif
