#ifndef _CChi2Graph_H_
#define _CChi2Graph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CChi2Graph CChi2Graph;

struct _CChi2Graph
{
	void (*FP_createChart)(CChi2Graph* pThis);
	void (*FP_writeChartAsJPEG)(CChi2Graph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CChi2Graph* getChi2Graph(char* modPth, double df);
void CChi2Graph_ctor(CChi2Graph* pThis, char* modPth, double df);
void CChi2Graph_dtor(CChi2Graph* pThis);
void CChi2Graph_createChart(CChi2Graph* pThis);
void CChi2Graph_writeChartAsJPEG(CChi2Graph* pThis, char* fileName);
#endif
