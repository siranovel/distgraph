#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CLaGraph.h"

static void usage(char* exeNm);
void laGraph(CLaGraph* pThis);
int main(int argc, char* argv[])
{
	double mu = 0.0;
	double beta = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mu);
	sscanf(argv[3], "%lf", &beta);
	
	CLaGraph* pThis = getLaGraph(updModPth, mu, beta);
	
	laGraph(pThis);
	CLaGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <mu> <beta> \n", exeNm);
}
void laGraph(CLaGraph* pThis)
{
	CLaGraph_createChart(pThis);
	CLaGraph_writeChartAsJPEG(pThis, "laGraph.jpg");
}
