#ifndef _JLaplaceDistribution_H_
#define _JLaplaceDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JLaplaceDistribution JLaplaceDistribution;

struct _JLaplaceDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject laDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject laDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define LA_DIST "org.apache.commons.math3.distribution.LaplaceDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newLaplaceDistribution(JNIEnv* env, jobject loader, double mu, double beta);
jdouble JLaplaceDistribution_density(JNIEnv* env, jobject laDistObj, jdouble x);
jdouble JLaplaceDistribution_logDensity(JNIEnv* env, jobject laDistObj, jdouble x);

#endif
