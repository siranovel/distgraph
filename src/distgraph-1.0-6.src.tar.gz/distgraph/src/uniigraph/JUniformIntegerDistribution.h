#ifndef _JUniformIntegerDistribution_H_
#define _JUniformIntegerDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JUniformIntegerDistribution JUniformIntegerDistribution;

struct _JUniformIntegerDistribution
{
	jdouble (*FP_probability)(JNIEnv* env, jobject uniiDistObj, jint x);
	jdouble (*FP_logProbability)(JNIEnv* env, jobject uniiDistObj, jint x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define UNII_DIST "org.apache.commons.math3.distribution.UniformIntegerDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newUniformIntegerDistribution(JNIEnv* env, jobject loader, jint low, jint up);
jdouble JUniformIntegerDistribution_probability(JNIEnv* env, jobject uniiDistObj, jint x);
jdouble JUniformIntegerDistribution_logProbability(JNIEnv* env, jobject uniiDistObj, jint x);

#endif
