#include <stdio.h>
#include <assert.h>
#include "JNormalDistribution.h"
#include "JClassLoader.h"

static jobject doNewNormalDistribution(JNIEnv* env, jobject loader, jdouble mean, jdouble sd);
static jdouble JNormalDistribution_doDensity(JNIEnv* env, jobject nDistObj, jdouble x);
static jdouble JNormalDistribution_doLogDensity(JNIEnv* env, jobject nDistObj, jdouble x);
static JNormalDistribution _jNDist = {
	.FP_density = JNormalDistribution_doDensity,
	.FP_logDensity = JNormalDistribution_doLogDensity,
};
jobject newNormalDistribution(JNIEnv* env, jobject loader, jdouble mean, jdouble sd)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewNormalDistribution(env, loader, mean, sd);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JNormalDistribution_density(JNIEnv* env, jobject nDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != nDistObj);
	return _jNDist.FP_density(env, nDistObj, x);
}
jdouble JNormalDistribution_logDensity(JNIEnv* env, jobject nDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != nDistObj);
	return _jNDist.FP_logDensity(env, nDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewNormalDistribution(JNIEnv* env, jobject loader, jdouble mean, jdouble sd)
{
	jvalue argValues[] = {
		[0] = { .d = mean},
		[1] = { .d = sd},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,N_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JNormalDistribution_doDensity(JNIEnv* env, jobject nDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, nDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, nDistObj, mid, argValues);
}
static jdouble JNormalDistribution_doLogDensity(JNIEnv* env, jobject nDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, nDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, nDistObj, mid, argValues);
}

