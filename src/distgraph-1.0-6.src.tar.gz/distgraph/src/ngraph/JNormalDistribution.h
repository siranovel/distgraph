#ifndef _JNormalDistribution_H_
#define _JNormalDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JNormalDistribution JNormalDistribution;

struct _JNormalDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject nDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject nDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define N_DIST "org.apache.commons.math3.distribution.NormalDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newNormalDistribution(JNIEnv* env, jobject loader, jdouble mean, jdouble sd);
jdouble JNormalDistribution_density(JNIEnv* env, jobject nDistObj, jdouble x);
jdouble JNormalDistribution_logDensity(JNIEnv* env, jobject nDistObj, jdouble x);

#endif
