#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CNGraph.h"

static void usage(char* exeNm);
void nGraph(CNGraph* pThis);
int main(int argc, char* argv[])
{
	double mean = 0.0;
	double sd = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mean);
	sscanf(argv[3], "%lf", &sd);
	
	CNGraph* pThis = getNGraph(updModPth, mean, sd);
	
	nGraph(pThis);
	CNGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <mean> <sd> \n", exeNm);
}
void nGraph(CNGraph* pThis)
{
	CNGraph_createChart(pThis);
	CNGraph_writeChartAsJPEG(pThis, "nGraph.jpg");
}
