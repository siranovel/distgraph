#ifndef _JPascalDistribution_H_
#define _JPascalDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JPascalDistribution JPascalDistribution;

struct _JPascalDistribution
{
	jdouble (*FP_probability)(JNIEnv* env, jobject pasDistObj, jint x);
	jdouble (*FP_logProbability)(JNIEnv* env, jobject pasDistObj, jint x);
	jdouble (*FP_cumulativeProbability)(JNIEnv* env, jobject pasDistObj, jint x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define PAS_DIST "org.apache.commons.math3.distribution.PascalDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newPascalDistribution(JNIEnv* env, jobject loader, jint r, jdouble p);
jdouble JPascalDistribution_probability(JNIEnv* env, jobject pasDistObj, jint x);
jdouble JPascalDistribution_logProbability(JNIEnv* env, jobject pasDistObj, jint x);
jdouble JPascalDistribution_cumulativeProbability(JNIEnv* env, jobject pasDistObj, jint x);

#endif
