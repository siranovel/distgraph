#include <stdio.h>
#include <assert.h>
#include "JCauchyDistribution.h"
#include "JClassLoader.h"


static jobject doNewCauchyDistribution(JNIEnv* env, jobject loader, jdouble median, jdouble scale);
static jdouble JCauchyDistribution_doDensity(JNIEnv* env, jobject cauchyDistObj, jdouble x);
static jdouble JCauchyDistribution_doLogDensity(JNIEnv* env, jobject cauchyDistObj, jdouble x);
static jdouble JCauchyDistribution_doCumulativeProbability(JNIEnv* env, jobject cauchyDistObj, jdouble x);
static JCauchyDistribution _jCauchyDist = {
	.FP_density = JCauchyDistribution_doDensity,
	.FP_logDensity = JCauchyDistribution_doLogDensity,
	.FP_cumulativeProbability = JCauchyDistribution_doCumulativeProbability,
};
jobject newCauchyDistribution(JNIEnv* env, jobject loader, jdouble median, jdouble scale)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewCauchyDistribution(env, loader, median, scale);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JCauchyDistribution_density(JNIEnv* env, jobject cauchyDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != cauchyDistObj);
	return _jCauchyDist.FP_density(env, cauchyDistObj, x);
}
jdouble JCauchyDistribution_logDensity(JNIEnv* env, jobject cauchyDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != cauchyDistObj);
	return _jCauchyDist.FP_logDensity(env, cauchyDistObj, x);
}
jdouble JCauchyDistribution_cumulativeProbability(JNIEnv* env, jobject cauchyDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != cauchyDistObj);
	return _jCauchyDist.FP_cumulativeProbability(env, cauchyDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewCauchyDistribution(JNIEnv* env, jobject loader, jdouble median, jdouble scale)
{
	jvalue argValues[] = {
		[0] = { .d = median},
		[1] = { .d = scale},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,CAUCHY_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JCauchyDistribution_doDensity(JNIEnv* env, jobject cauchyDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, cauchyDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, cauchyDistObj, mid, argValues);
}
static jdouble JCauchyDistribution_doLogDensity(JNIEnv* env, jobject cauchyDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, cauchyDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, cauchyDistObj, mid, argValues);
}
static jdouble JCauchyDistribution_doCumulativeProbability(JNIEnv* env, jobject cauchyDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, cauchyDistObj), "cumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, cauchyDistObj, mid, argValues);
}
