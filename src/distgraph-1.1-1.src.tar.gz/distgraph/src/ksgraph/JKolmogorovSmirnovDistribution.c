#include <stdio.h>
#include <assert.h>
#include "JKolmogorovSmirnovDistribution.h"
#include "JClassLoader.h"


static jobject doNewKolmogorovSmirnovDistribution(JNIEnv* env, jobject loader, jint n);
static jdouble JKolmogorovSmirnovDistribution_doCdf(JNIEnv* env, jobject ksDistObj, jdouble d);
static JKolmogorovSmirnovDistribution _jksDist = {
	.FP_cdf = JKolmogorovSmirnovDistribution_doCdf,
};
jobject newKolmogorovSmirnovDistribution(JNIEnv* env, jobject loader, jint n)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewKolmogorovSmirnovDistribution(env, loader, n);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JKolmogorovSmirnovDistribution_cdf(JNIEnv* env, jobject ksDistObj, jdouble d)
{
	assert(0 != env);
	assert(0 != ksDistObj);
	return _jksDist.FP_cdf(env, ksDistObj, d);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewKolmogorovSmirnovDistribution(JNIEnv* env, jobject loader, jint n)
{
	jvalue argValues[] = {
		[0] = { .i = n},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,KS_DIST));
	
	return JClass_NewObjectA(env, clz, "(I)V", argValues);
}
static jdouble JKolmogorovSmirnovDistribution_doCdf(JNIEnv* env, jobject ksDistObj, jdouble d)
{
	jvalue argValues[] = {
		[0] = { .d = d},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, ksDistObj), "cdf", "(D)D");
	
	return JClass_CallDoubleMethodA(env, ksDistObj, mid, argValues);
}

