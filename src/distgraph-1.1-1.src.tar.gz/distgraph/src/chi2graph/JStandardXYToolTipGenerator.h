#ifndef _JStandardXYToolTipGenerator_H_
#define _JStandardXYToolTipGenerator_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
/**************************************/
/* define�錾                         */
/**************************************/
#define StandardXYToolTipGenerator "org.jfree.chart.labels.StandardXYToolTipGenerator"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newStandardXYToolTipGenerator(JNIEnv* env, jobject loader);
#endif
