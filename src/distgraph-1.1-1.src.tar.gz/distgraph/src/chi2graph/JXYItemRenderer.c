#include <stdio.h>
#include <assert.h>
#include "JXYItemRenderer.h"

static void JXYItemRenderer_doSetBaseToolTipGenerator(JNIEnv* env, jobject render, jobject generator);
static JXYItemRenderer _jXYItemRender = {
	.FP_setBaseToolTipGenerator = JXYItemRenderer_doSetBaseToolTipGenerator,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JXYItemRenderer_setBaseToolTipGenerator(JNIEnv* env, jobject render, jobject generator)
{
	assert(env != 0);
	assert(render != 0);
	assert(generator != 0);
	_jXYItemRender.FP_setBaseToolTipGenerator(env, render, generator);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void JXYItemRenderer_doSetBaseToolTipGenerator(JNIEnv* env, jobject render, jobject generator)
{
	jvalue argValues[] = {
		[0] = { .l = generator},
	};
	
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, render), "setBaseToolTipGenerator", "(Lorg/jfree/chart/labels/XYToolTipGenerator;)V");
	JClass_CallVoidMethodA(env, render, mid, argValues);
}

