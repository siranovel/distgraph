#include <stdio.h>
#include <assert.h>
#include "JStandardXYToolTipGenerator.h"
#include "JClassLoader.h"

static jobject doNewStandardXYToolTipGenerator(JNIEnv* env, jobject loader);
jobject newStandardXYToolTipGenerator(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewStandardXYToolTipGenerator(env, loader);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewStandardXYToolTipGenerator(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,StandardXYToolTipGenerator));
	
	return JClass_NewObjectA(env, clz, "()V", NULL);
}
