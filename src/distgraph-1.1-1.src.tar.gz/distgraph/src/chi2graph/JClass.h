#ifndef _JClass_H_
#define _JClass_H_

#include "jni.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JClass JClass;

struct _JClass
{
	jclass       (*FP_FindClass)(JNIEnv* env, char* className);
	jmethodID    (*FP_GetMethodID)(JNIEnv* env, jclass clz, char* funcName, char* sig);
	jmethodID    (*FP_GetStaticMethodID)(JNIEnv* env, jclass clz, char* funcName, char* sig);
	jclass       (*FP_GetObjectClass)(JNIEnv* env, jclass clzObject);
	jobject      (*FP_NewObjectA)(JNIEnv* env, jclass clz, char* sig, jvalue* argValues);
	jboolean     (*FP_IsInstanceOf)(JNIEnv* env, jobject pObj, jclass clazz);
	char*        (*FP_GetStringUTFChars)(JNIEnv* env, jstring jstr);
	
	jstring      (*FP_StringNew)(JNIEnv* env, char* s);
	jobjectArray (*FP_NewObjectArray)(JNIEnv *env, jsize len, jclass clz, jobject init);
	void         (*FP_SetObjectArrayElement)(JNIEnv *env, jobjectArray array, jsize index, jobject val);
	
	void         (*FP_CallStaticVoidMethodA)(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
	jobject      (*FP_CallStaticObjectMethodA)(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);
	jdouble      (*FP_CallStaticDoubleMethodA)(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);
	jlong        (*FP_CallStaticLongMethodA)(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);
	
	void         (*FP_CallVoidMethodA)(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);
	jobject      (*FP_CallObjectMethodA)(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
	jboolean     (*FP_CallBooleanMethodA)(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
	jdouble      (*FP_CallDoubleMethodA)(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
	
	jfieldID     (*FP_GetStaticFieldID)(JNIEnv* env, jclass clz, const char* name, const char* sig);
	jobject      (*FP_GetStaticObjectField)(JNIEnv* env, jclass clz, jfieldID fid);
	
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jclass JClass_FindClass(JNIEnv* env, char* className);
jmethodID JClass_GetMethodID(JNIEnv* env, jclass clz, char* funcName, char* sig);
jmethodID JClass_GetStaticMethodID(JNIEnv* env, jclass clz, char* funcName, char* sig);
jclass JClass_GetObjectClass(JNIEnv* env, jclass clzObject);
jobject JClass_NewObjectA(JNIEnv* env, jclass clz, char* sig, jvalue* argValues);
jboolean JClass_IsInstanceOf(JNIEnv* env, jobject pObj, jclass clazz);
char* JClass_GetStringUTFChars(JNIEnv* env, jstring jstr);

jstring JClass_StringNew(JNIEnv* env, char* s);
jobjectArray JClass_NewObjectArray(JNIEnv *env, jsize len, jclass clz, jobject init);
void JClass_SetObjectArrayElement(JNIEnv *env, jobjectArray array, jsize index, jobject val);

void JClass_CallStaticVoidMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);
jobject JClass_CallStaticObjectMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);
jdouble JClass_CallStaticDoubleMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);
jlong JClass_CallStaticLongMethodA(JNIEnv* env, jclass clz, jmethodID mid, const jvalue * args);

void JClass_CallVoidMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
jobject JClass_CallObjectMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
jboolean JClass_CallBooleanMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);
jdouble JClass_CallDoubleMethodA(JNIEnv* env, jobject clzObject, jmethodID mid, const jvalue * args);

jfieldID JClass_GetStaticFieldID(JNIEnv* env, jclass clz, const char* name, const char* sig);
jobject JClass_GetStaticObjectField(JNIEnv* env, jclass clz, jfieldID fid);

#endif
