#include <stdio.h>
#include <assert.h>
#include "JPlotOrientation.h"
#include "JClassLoader.h"

static jobject JPlotOrientation_doHORIZONTAL(JNIEnv* env, jobject loader);
static jobject JPlotOrientation_doVERTICAL(JNIEnv* env, jobject loader);
static JPlotOrientation _jPlotOrientation = {
	.FP_HORIZONTAL = JPlotOrientation_doHORIZONTAL,
	.FP_VERTICAL = JPlotOrientation_doVERTICAL,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JPlotOrientation_HORIZONTAL(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return _jPlotOrientation.FP_HORIZONTAL(env, loader);
}
jobject JPlotOrientation_VERTICAL(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return _jPlotOrientation.FP_VERTICAL(env, loader);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JPlotOrientation_doHORIZONTAL(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,PlotOrientation));
	jfieldID fid = JClass_GetStaticFieldID(env, clz, "HORIZONTAL", "Lorg/jfree/chart/plot/PlotOrientation;");
	
	return JClass_GetStaticObjectField(env, clz, fid);
}
static jobject JPlotOrientation_doVERTICAL(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,PlotOrientation));
	jfieldID fid = JClass_GetStaticFieldID(env, clz, "VERTICAL", "Lorg/jfree/chart/plot/PlotOrientation;");
	
	return JClass_GetStaticObjectField(env, clz, fid);
}
