#ifndef _JChiSquaredDistribution_H_
#define _JChiSquaredDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JChiSquaredDistribution JChiSquaredDistribution;

struct _JChiSquaredDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject chiDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject chiDistObj, jdouble x);
	jdouble (*FP_cumulativeProbability)(JNIEnv* env, jobject chiDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define CHI_DIST "org.apache.commons.math3.distribution.ChiSquaredDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newChiSquaredDistribution(JNIEnv* env, jobject loader, jdouble df);
jdouble JChiSquaredDistribution_density(JNIEnv* env, jobject chiDistObj, jdouble x);
jdouble JChiSquaredDistribution_logDensity(JNIEnv* env, jobject chiDistObj, jdouble x);
jdouble JChiSquaredDistribution_cumulativeProbability(JNIEnv* env, jobject chiDistObj, jdouble x);
#endif
