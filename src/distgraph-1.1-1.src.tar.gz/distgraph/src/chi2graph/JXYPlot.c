#include <stdio.h>
#include <assert.h>
#include "JXYPlot.h"
#include "JClassLoader.h"


static jobject doNewXYPlot(JNIEnv* env, jobject loader);
static void JXYPlot_doSetOrientation(JNIEnv* env, jobject xyPlot, jobject orientation);
static void JXYPlot_doSetDomainAxis(JNIEnv* env, jobject xyPlot, jobject axis);
static void JXYPlot_doSetRangeAxis(JNIEnv* env, jobject xyPlot, int index, jobject axis);
static void JXYPlot_doSetDataset(JNIEnv* env, jobject xyPlot, int index, jobject dataset);
static void JXYPlot_doSetRenderer(JNIEnv* env, jobject xyPlot, int index, jobject renderer);
static JXYPlot _jXYPlot = {
	.FP_setOrientation = JXYPlot_doSetOrientation,
	.FP_setDomainAxis = JXYPlot_doSetDomainAxis,
	.FP_setRangeAxis = JXYPlot_doSetRangeAxis,
	.FP_setDataset = JXYPlot_doSetDataset,
	.FP_setRenderer = JXYPlot_doSetRenderer,
};
jobject newXYPlot(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewXYPlot(env, loader);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JXYPlot_setOrientation(JNIEnv* env, jobject xyPlot, jobject orientation)
{
	assert(env != 0);
	assert(xyPlot != 0);
	assert(orientation != 0);
	_jXYPlot.FP_setOrientation(env, xyPlot, orientation);
}
void JXYPlot_setDomainAxis(JNIEnv* env, jobject xyPlot, jobject axis)
{
	assert(env != 0);
	assert(xyPlot != 0);
	assert(axis != 0);
	_jXYPlot.FP_setDomainAxis(env, xyPlot, axis);
}
void JXYPlot_setRangeAxis(JNIEnv* env, jobject xyPlot, int index, jobject axis)
{
	assert(env != 0);
	assert(xyPlot != 0);
	assert(axis != 0);
	_jXYPlot.FP_setRangeAxis(env, xyPlot, index, axis);
}
void JXYPlot_setDataset(JNIEnv* env, jobject xyPlot, int index, jobject dataset)
{
	assert(env != 0);
	assert(xyPlot != 0);
	assert(dataset != 0);
	_jXYPlot.FP_setDataset(env, xyPlot, index, dataset);
}
void JXYPlot_setRenderer(JNIEnv* env, jobject xyPlot, int index, jobject renderer)
{
	assert(env != 0);
	assert(xyPlot != 0);
	assert(renderer != 0);
	_jXYPlot.FP_setRenderer(env, xyPlot, index, renderer);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewXYPlot(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,XYPlot));
	
	return JClass_NewObjectA(env, clz, "()V", 0);
}
static void JXYPlot_doSetDomainAxis(JNIEnv* env, jobject xyPlot, jobject axis)
{
	jvalue argValues[] = {
		[0] = { .l = axis},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, xyPlot), "setDomainAxis", "(Lorg/jfree/chart/axis/ValueAxis;)V");

	JClass_CallVoidMethodA(env, xyPlot, mid, argValues);
}
static void JXYPlot_doSetOrientation(JNIEnv* env, jobject xyPlot, jobject orientation)
{
	jvalue argValues[] = {
		[0] = { .l = orientation},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, xyPlot), "setOrientation", "(Lorg/jfree/chart/plot/PlotOrientation;)V");
	
	JClass_CallVoidMethodA(env, xyPlot, mid, argValues);
}
static void JXYPlot_doSetRangeAxis(JNIEnv* env, jobject xyPlot, int index, jobject axis)
{
	jvalue argValues[] = {
		[0] = { .i = index},
		[1] = { .l = axis},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, xyPlot), "setRangeAxis", "(ILorg/jfree/chart/axis/ValueAxis;)V");

	JClass_CallVoidMethodA(env, xyPlot, mid, argValues);
}
static void JXYPlot_doSetDataset(JNIEnv* env, jobject xyPlot, int index, jobject dataset)
{
	jvalue argValues[] = {
		[0] = { .i = index},
		[1] = { .l = dataset},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, xyPlot), "setDataset", "(ILorg/jfree/data/xy/XYDataset;)V");

	JClass_CallVoidMethodA(env, xyPlot, mid, argValues);
}
static void JXYPlot_doSetRenderer(JNIEnv* env, jobject xyPlot, int index, jobject renderer)
{
	jvalue argValues[] = {
		[0] = { .i = index},
		[1] = { .l = renderer},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, xyPlot), "setRenderer", "(ILorg/jfree/chart/renderer/xy/XYItemRenderer;)V");

	JClass_CallVoidMethodA(env, xyPlot, mid, argValues);
}
