#include <stdio.h>
#include <assert.h>
#include "JXYSeries.h"
#include "JClassLoader.h"

static jobject doNewXYSeries(JNIEnv* env, jobject loader, jstring key);
static void JXYSeries_doAdd(JNIEnv* env, jobject series, double x, double y);
static JXYSeries _jXseries = {
	.FP_add = JXYSeries_doAdd,
};
jobject newXYSeries(JNIEnv* env, jobject loader, jstring key)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewXYSeries(env, loader, key);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JXYSeries_add(JNIEnv* env, jobject series, double x, double y)
{
	assert(env != 0);
	assert(series != 0);
	_jXseries.FP_add(env, series, x, y);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewXYSeries(JNIEnv* env, jobject loader, jstring key)
{
	jvalue argValues[] = {
		[0] = { .l = key},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,XYSeries));
	
	return JClass_NewObjectA(env, clz, "(Ljava/lang/Comparable;)V", argValues);
}
static void JXYSeries_doAdd(JNIEnv* env, jobject series, double x, double y)
{
	jvalue argValues[] = {
		[0] = { .d = x},
		[1] = { .d = y},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, series), "add", "(DD)V");
	
	JClass_CallVoidMethodA(env, series, mid, argValues);
}
