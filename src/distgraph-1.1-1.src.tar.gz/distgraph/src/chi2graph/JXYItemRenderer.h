#ifndef _JXYItemRenderer_H_
#define _JXYItemRenderer_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JXYItemRenderer JXYItemRenderer;

struct _JXYItemRenderer
{
	void (*FP_setBaseToolTipGenerator)(JNIEnv* env, jobject renderer, jobject generator);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
void JXYItemRenderer_setBaseToolTipGenerator(JNIEnv* env, jobject render, jobject generator);
#endif
