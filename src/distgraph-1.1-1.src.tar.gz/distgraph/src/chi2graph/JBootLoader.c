#include <stdio.h>
#include <assert.h>
#include "JBootLoader.h"

static void JBootLoader_doLoadModule(JNIEnv* env, jobject mref);
static JBootLoader _jBootLoader = {
	.FP_loadModule = JBootLoader_doLoadModule,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JBootLoader_loadModule(JNIEnv* env, jobject mref)
{
	_jBootLoader.FP_loadModule(env, mref);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void JBootLoader_doLoadModule(JNIEnv* env, jobject mref)
{
	jvalue argValues[] = {
		[0] = { .l = mref},
	};
	jclass clz = JClass_FindClass(env, "jdk/internal/loader/BootLoader");
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "loadModule", "(Ljava/lang/module/ModuleReference;)V");
	JClass_CallStaticVoidMethodA(env, clz, mid, argValues);
}
