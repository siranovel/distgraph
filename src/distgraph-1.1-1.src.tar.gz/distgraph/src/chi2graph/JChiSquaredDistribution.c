#include <stdio.h>
#include <assert.h>
#include "JChiSquaredDistribution.h"
#include "JClassLoader.h"

static jobject doNewChiSquaredDistribution(JNIEnv* env, jobject loader, jdouble df);
static jdouble JChiSquaredDistribution_doDensity(JNIEnv* env, jobject chiDistObj, jdouble x);
static jdouble JChiSquaredDistribution_doLogDensity(JNIEnv* env, jobject chiDistObj, jdouble x);
static jdouble JChiSquaredDistribution_doCumulativeProbability(JNIEnv* env, jobject chiDistObj, jdouble x);
static JChiSquaredDistribution _jChiDist = {
	.FP_density = JChiSquaredDistribution_doDensity,
	.FP_logDensity = JChiSquaredDistribution_doLogDensity,
	.FP_cumulativeProbability = JChiSquaredDistribution_doCumulativeProbability,
};
jobject newChiSquaredDistribution(JNIEnv* env, jobject loader, jdouble df)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewChiSquaredDistribution(env, loader, df);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JChiSquaredDistribution_density(JNIEnv* env, jobject chiDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != chiDistObj);
	return _jChiDist.FP_density(env, chiDistObj, x);
}
jdouble JChiSquaredDistribution_logDensity(JNIEnv* env, jobject chiDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != chiDistObj);
	return _jChiDist.FP_logDensity(env, chiDistObj, x);
}
jdouble JChiSquaredDistribution_cumulativeProbability(JNIEnv* env, jobject chiDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != chiDistObj);
	return _jChiDist.FP_cumulativeProbability(env, chiDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewChiSquaredDistribution(JNIEnv* env, jobject loader, jdouble df)
{
	jvalue argValues[] = {
		[0] = { .d = df},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,CHI_DIST));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
static jdouble JChiSquaredDistribution_doDensity(JNIEnv* env, jobject chiDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, chiDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, chiDistObj, mid, argValues);
}
static jdouble JChiSquaredDistribution_doLogDensity(JNIEnv* env, jobject chiDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, chiDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, chiDistObj, mid, argValues);
}
static jdouble JChiSquaredDistribution_doCumulativeProbability(JNIEnv* env, jobject chiDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, chiDistObj), "cumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, chiDistObj, mid, argValues);
}
