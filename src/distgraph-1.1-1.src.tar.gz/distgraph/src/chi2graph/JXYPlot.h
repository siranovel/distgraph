#ifndef _JXYPlot_H_
#define _JXYPlot_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JXYPlot JXYPlot;

struct _JXYPlot
{
	void (*FP_setOrientation)(JNIEnv* env, jobject xyPlot, jobject orientation);
	void (*FP_setDomainAxis)(JNIEnv* env, jobject xyPlot, jobject axis);
	void (*FP_setRangeAxis)(JNIEnv* env, jobject xyPlot, int index, jobject axis);
	void (*FP_setDataset)(JNIEnv* env, jobject xyPlot, int index, jobject dataset);
	void (*FP_setRenderer)(JNIEnv* env, jobject xyPlot, int index, jobject renderer);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define XYPlot "org.jfree.chart.plot.XYPlot"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newXYPlot(JNIEnv* env, jobject loader);
void JXYPlot_setOrientation(JNIEnv* env, jobject xyPlot, jobject orientation);
void JXYPlot_setDomainAxis(JNIEnv* env, jobject xyPlot, jobject axis);
void JXYPlot_setRangeAxis(JNIEnv* env, jobject xyPlot, int index, jobject axis);
void JXYPlot_setDataset(JNIEnv* env, jobject xyPlot, int index, jobject dataset);
void JXYPlot_setRenderer(JNIEnv* env, jobject xyPlot, int index, jobject renderer);
#endif
