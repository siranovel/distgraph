#include <stdio.h>
#include <assert.h>
#include "JDatasetRenderingOrder.h"
#include "JClassLoader.h"

static jobject JDatasetRenderingOrder_doFORWARD(JNIEnv* env, jobject loader);
static jobject JDatasetRenderingOrder_doREVERSE(JNIEnv* env, jobject loader);
static JDatasetRenderingOrder _jDtsetRenderOrder = {
	.FP_FORWARD = JDatasetRenderingOrder_doFORWARD,
	.FP_REVERSE = JDatasetRenderingOrder_doREVERSE,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JDatasetRenderingOrder_FORWARD(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return _jDtsetRenderOrder.FP_FORWARD(env, loader);
}
jobject JDatasetRenderingOrder_REVERSE(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return _jDtsetRenderOrder.FP_REVERSE(env, loader);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JDatasetRenderingOrder_doFORWARD(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,DatasetRenderingOrder));
	jfieldID fid = JClass_GetStaticFieldID(env, clz, "FORWARD", "Lorg/jfree/chart/plot/DatasetRenderingOrder;");
	return JClass_GetStaticObjectField(env, clz, fid);
}
static jobject JDatasetRenderingOrder_doREVERSE(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,DatasetRenderingOrder));
	jfieldID fid = JClass_GetStaticFieldID(env, clz, "REVERSE", "Lorg/jfree/chart/plot/DatasetRenderingOrder;");
	return JClass_GetStaticObjectField(env, clz, fid);
}
