#ifndef _JParetoDistribution_H_
#define _JParetoDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JParetoDistribution JParetoDistribution;

struct _JParetoDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject parDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject parDistObj, jdouble x);
	jdouble (*FP_cumulativeProbability)(JNIEnv* env, jobject parDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define PAR_DIST "org.apache.commons.math3.distribution.ParetoDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newParetoDistribution(JNIEnv* env, jobject loader, jdouble scale, jdouble shape);
jdouble JParetoDistribution_density(JNIEnv* env, jobject parDistObj, jdouble x);
jdouble JParetoDistribution_logDensity(JNIEnv* env, jobject parDistObj, jdouble x);
jdouble JParetoDistribution_cumulativeProbability(JNIEnv* env, jobject parDistObj, jdouble x);

#endif
