#ifndef _CParGraph_H_
#define _CParGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CParGraph CParGraph;

struct _CParGraph
{
	void (*FP_createChart)(CParGraph* pThis);
	void (*FP_writeChartAsJPEG)(CParGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CParGraph* getCParGraph(char* modPth, double scale, double shape);
void CParGraph_ctor(CParGraph* pThis, char* modPth, double scale, double shape);
void CParGraph_dtor(CParGraph* pThis);
void CParGraph_createChart(CParGraph* pThis);
void CParGraph_writeChartAsJPEG(CParGraph* pThis, char* fileName);

#endif
