#ifndef _CUniIGraph_H_
#define _CUniIGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CUniIGraph CUniIGraph;

struct _CUniIGraph
{
	void (*FP_createChart)(CUniIGraph* pThis);
	void (*FP_writeChartAsJPEG)(CUniIGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CUniIGraph* getUniIGraph(char* modPth, int low, int up);
void CUniIGraph_ctor(CUniIGraph* pThis, char* modPth, int low, int up);
void CUniIGraph_dtor(CUniIGraph* pThis);
void CUniIGraph_createChart(CUniIGraph* pThis);
void CUniIGraph_writeChartAsJPEG(CUniIGraph* pThis, char* fileName);

#endif
