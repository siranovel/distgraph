#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "CLaGraph.h"
#include "JPaths.h"
#include "JModuleFinder.h"
#include "JSet.h"
#include "JIterator.h"
#include "JModuleReference.h"
#include "JModuleDescriptor.h"
#include "JModuleLayer.h"
#include "JConfiguration.h"
#include "JModuleLoaderMap.h"
#include "JResolvedModule.h"
#include "JFunction.h"
#include "JBootLoader.h"
#include "JBuiltinClassLoader.h"
#include "JClassLoader.h"

#include "JLaplaceDistribution.h"

#include "JChartUtilities.h"
#include "JXYSeries.h"
#include "JXYSeriesCollection.h"
#include "JChartFactory.h"
#include "JJFreeChart.h"
#include "JPlot.h"
#include "JValueAxis.h"
#include "JTextTitle.h"
#include "JXYPlot.h"
#include "JNumberAxis.h"
#include "JXYLineAndShapeRenderer.h"
#include "JStandardXYToolTipGenerator.h"
#include "JXYItemRenderer.h"
#include "JPlotOrientation.h"
#include "JDatasetRenderingOrder.h"

static double _mu = 0.0;
static double _beta = 0.0;
static double _from = 0.0;
static double _to = 0.0;
static JavaVM* _vm = 0;
static JNIEnv* _env = 0;
static jobject _loader1 = 0;
static jobject _loader2 = 0;
static jobject _beDistObj = 0;
static jobject _chart = 0;

static void CLaGraph_doCreateChart(CLaGraph* pThis);
static jobject createPlot(JNIEnv* env, jobject dataset0, jobject dataset1);
static jobject createDataSet0(JNIEnv* env);
static jobject createDataSet1(JNIEnv* env);
static void CLaGraph_doWriteChartAsJPEG(CLaGraph* pThis, char* fileName);
static void init();
static void end();
static void updModPth(char* modPth);
static void loadModules(JNIEnv* env, jobject cf, jobject clf);

static CLaGraph _cLaGraph = {
    .FP_createChart = CLaGraph_doCreateChart,
	.FP_writeChartAsJPEG = CLaGraph_doWriteChartAsJPEG,
};
CLaGraph* getLaGraph(char* modPth, double mu, double beta)
{
	CLaGraph_ctor(&_cLaGraph, modPth, mu, beta);
	return &_cLaGraph;
}
void CLaGraph_ctor(CLaGraph* pThis, char* modPth, double mu, double beta)
{
	init();
	updModPth(modPth);
	
	_mu = mu;
	_beta = beta;
	_from = -20;
	_to = mu * beta;
	_beDistObj = newLaplaceDistribution(_env, _loader1, mu, beta);
	// ���ܸ줬ʸ���������ʤ��ơ���
	JChartFactory_setChartTheme(_env, _loader2);
}
void CLaGraph_dtor(CLaGraph* pThis)
{
	end();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CLaGraph_createChart(CLaGraph* pThis)
{
	assert(pThis != 0);
	pThis->FP_createChart(pThis);
}
void CLaGraph_writeChartAsJPEG(CLaGraph* pThis, char* fileName)
{
	assert(pThis != 0);
	assert(_chart != 0);
	pThis->FP_writeChartAsJPEG(pThis, fileName);
}
/**************************************/
/* �����¹���                         */
/**************************************/
static void CLaGraph_doCreateChart(CLaGraph* pThis)
{
	jobject title = JClass_StringNew(_env, "��ץ饹ʬ�ۤΥ����");
	jobject domainAxis = newNumberAxis(_env, _loader2, "x");
	jobject plot = createPlot(_env, createDataSet0(_env), createDataSet1(_env) );
	char subTitle[64];
	sprintf(subTitle, "(mu=%lf beta=%lf)", _mu, _beta);
	
	/*--- ���� ---*/
	JXYPlot_setDomainAxis(_env, plot, domainAxis);
	JValueAxis_setLowerBound(_env, domainAxis, _from);
	JValueAxis_setUpperBound(_env, domainAxis, _to);
	
	_chart = newJFreeChart(_env, _loader2, title, plot);
	JJFreeChart_addSubtitle(_env, _chart, newTextTitle(_env, _loader2, JClass_StringNew(_env, subTitle)));
}
static jobject createPlot(JNIEnv* env, jobject dataset0, jobject dataset1)
{
	assert(_env != 0);
	assert(dataset0 != 0);
	assert(dataset1 != 0);
	jobject valueAxis0 = newNumberAxis(_env, _loader2, "̩��");
	jobject valueAxis1 = newNumberAxis(_env, _loader2, "P");
	// Renderer
	jobject renderer0 = newXYLineAndShapeRenderer(_env, _loader2, JNI_TRUE, JNI_FALSE); // XYItemRenderer renderer = new XYLineAndShapeRenderer(true, false);
	jobject renderer1 = newXYLineAndShapeRenderer(_env, _loader2, JNI_TRUE, JNI_FALSE); // XYItemRenderer renderer = new XYLineAndShapeRenderer(true, false);
	jobject generator = newStandardXYToolTipGenerator(_env, _loader2);

	JXYItemRenderer_setBaseToolTipGenerator(_env, renderer0, generator);
	JXYItemRenderer_setBaseToolTipGenerator(_env, renderer1, generator);
	
	// XYPlot
	jobject plot = newXYPlot(_env, _loader2);
	JXYPlot_setOrientation(_env, plot, JPlotOrientation_VERTICAL(_env, _loader2));
	JPlot_mapDatasetToRangeAxis(_env, plot, 0, 0);
	JPlot_mapDatasetToRangeAxis(_env, plot, 1, 1);
	JPlot_setDatasetRenderingOrder(_env, plot, JDatasetRenderingOrder_FORWARD(_env, _loader2));
	
	/*--- �ļ� ---*/
	JXYPlot_setRangeAxis(_env, plot, 0, valueAxis0);
	JXYPlot_setDataset(_env, plot, 0, dataset0);
	JXYPlot_setRenderer(_env, plot, 0, renderer0);
	JValueAxis_setLowerBound(_env, valueAxis0, 0.0);
	JValueAxis_setTickUnit(_env, _loader2, valueAxis0, 0.01);
	JValueAxis_setNumberFormatOverride(_env, valueAxis0, "0.0#");
	
	JXYPlot_setRangeAxis(_env, plot, 1, valueAxis1);
	JXYPlot_setDataset(_env, plot, 1, dataset1);
	JXYPlot_setRenderer(_env, plot, 1, renderer1);
	JValueAxis_setLowerBound(_env, valueAxis1, 0.0);
	JValueAxis_setUpperBound(_env, valueAxis1, 1.0);
	JValueAxis_setTickUnit(_env, _loader2, valueAxis1, 0.1);
	JValueAxis_setNumberFormatOverride(_env, valueAxis1, "0.0#");
	return plot;
	
}
static jobject createDataSet0(JNIEnv* env)
{
	double x;
	jobject p = newXYSeries(env, _loader2, JClass_StringNew(_env, "P"));
	
	for (x = _from; x <= _to; x += DT) {
		JXYSeries_add(env, p, x, JLaplaceDistribution_density(_env, _beDistObj, x));
	}
	
	jobject series = newXYSeriesCollection(env, _loader2);
	JXYSeriesCollection_addSeries(env, series, p);
	return series;
}
static jobject createDataSet1(JNIEnv* env)
{
	double x;
	jobject cu = newXYSeries(env, _loader2, JClass_StringNew(_env, "����"));
	
	for (x = _from; x <= _to; x += DT) {
		JXYSeries_add(env, cu, x, JLaplaceDistribution_cumulativeProbability(_env, _beDistObj, x));
	}
	jobject series = newXYSeriesCollection(env, _loader2);
	JXYSeriesCollection_addSeries(env, series, cu);
	return series;
}
static void CLaGraph_doWriteChartAsJPEG(CLaGraph* pThis, char* fileName)
{
	JChartUtilities_writeChartAsJPEG(_env, _loader2, JClass_StringNew(_env, fileName), _chart, 800, 500);
}


static JavaVMOption jvmOpts[] = {
	{.optionString = "-XX:+UnlockExperimentalVMOptions", .extraInfo=NULL}
	,{.optionString = "-XX:+EnableJVMCI", .extraInfo=NULL}
	
};
static JavaVMInitArgs vm_args = {
	.version = JNI_VERSION_1_8,
	.nOptions = NSIZE(jvmOpts),
	.options = jvmOpts
};
static void init()
{
	JNI_CreateJavaVM(&_vm, (void **)&_env, (void *)&vm_args);
	
}
static void end()
{
	assert(_vm != NULL);
	(*_vm)->DestroyJavaVM(_vm);
}
static void updModPth(char* modPth)
{
	jobject jmodPath = JPaths_get(_env, modPth);
	jobject mfinder = JModuleFinder_of(_env, jmodPath);
	jobject refs = JModuleFinder_findAll(_env, mfinder);
	jobject iteObj = JSet_iterator(_env, refs);
	
	jobject roots = newSet(_env);
	while(JNI_TRUE == JIterator_hasNext(_env, iteObj)) {
		jobject mref = JIterator_next(_env, iteObj);          // ModuleReference
		jobject mdesc = JModuleReference_descriptor(_env, mref); // ModuleDescriptor
		jstring jdescName = JModuleDescriptor_name(_env, mdesc);
		
		JSet_add(_env, roots, jdescName);
	}
	/*
     *    ModuleFinder finder = ModuleFinder.of(dir1, dir2, dir3);
	 *    ModuleLayer bootLayer = ModuleLayer.boot();
     *    Configuration parent = bootLayer.configuration();
     *    Configuration cf = parent.resolve(finder, ModuleFinder.of(new Path[0]), Set.of("myapp"));
	 *    Function<String, ClassLoader> clf = ModuleLoaderMap.mappingFunction(cf);
     *    ModuleBootstrap.loadModules(cf, clf);
     *        for (ResolvedModule resolvedModule : cf.modules()) {
     *            ModuleReference mref = resolvedModule.reference();
     *            String name = resolvedModule.name();
     *            ClassLoader loader = clf.apply(name);
     *            if (loader == null) {
     *               // skip java.base as it is already loaded
     *               if (!name.equals(JAVA_BASE)) {
     *                   BootLoader.loadModule(mref);
     *               }
     *            } else if (loader instanceof BuiltinClassLoader) {
     *                ((BuiltinClassLoader) loader).loadModule(mref);
     *            }
     *        }
	 */
	jobject bootLayer = JModuleLayer_boot(_env);
	jobject parent = JModuleLayer_configuration(_env, bootLayer);
	jobject cf = JConfiguration_resolveAndBind(_env, parent, mfinder, JModuleFinder_of(_env, 0), roots);
	jobject clf = JModuleLoaderMap_mappingFunction(_env, cf);
	
	loadModules(_env, cf, clf);
	jobject emptyM = JModuleLayer_defineModules(_env, bootLayer, cf, clf);
	_loader1 = JModuleLayer_findLoader(_env, emptyM, JClass_StringNew(_env,"commons.math3"));  // ClassLoader jdbc = emptyM.findLoader("commons.math3")
	
	_loader2 = JModuleLayer_findLoader(_env, emptyM, JClass_StringNew(_env,"jfreechart"));  // ClassLoader jdbc = emptyM.findLoader("jfreechart")
}
static void loadModules(JNIEnv* env, jobject cf, jobject clf)
{
	jobject reslvedMs = JConfiguration_modules(env, cf);
	jobject iteObj = JSet_iterator(env, reslvedMs);

	while(JNI_TRUE == JIterator_hasNext(env, iteObj)) {
		jobject resolvedModule = JIterator_next(env, iteObj);          // ResolvedModule
		jobject mref = JResolvedModule_reference(env, resolvedModule); // ModuleReference
		jstring name = JResolvedModule_name(env, resolvedModule);
		jobject loader = JFunction_apply(env, clf, name);

		if (0 == loader) {
			const char* _name = JClass_GetStringUTFChars(env, name);
			
			if (0 != strcmp("java.base", _name)) {
				JBootLoader_loadModule(env, mref);
			}
		} else if (JNI_TRUE == JClass_IsInstanceOf(env, loader, JClass_FindClass(env, "jdk/internal/loader/BuiltinClassLoader"))) {
			JBuiltinClassLoader_loadModule(env, loader, mref);
		}
	}
}
