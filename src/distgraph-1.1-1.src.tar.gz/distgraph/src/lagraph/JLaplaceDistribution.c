#include <stdio.h>
#include <assert.h>
#include "JLaplaceDistribution.h"
#include "JClassLoader.h"

static jobject doNewLaplaceDistribution(JNIEnv* env, jobject loader, double mu, double beta);
static jdouble JLaplaceDistribution_doDensity(JNIEnv* env, jobject laDistObj, jdouble x);
static jdouble JLaplaceDistribution_doLogDensity(JNIEnv* env, jobject laDistObj, jdouble x);
static jdouble JLaplaceDistribution_doCumulativeProbability(JNIEnv* env, jobject laDistObj, jdouble x);
static JLaplaceDistribution _jLaDist = {
	.FP_density = JLaplaceDistribution_doDensity,
	.FP_logDensity = JLaplaceDistribution_doLogDensity,
	.FP_cumulativeProbability = JLaplaceDistribution_doCumulativeProbability,
};
jobject newLaplaceDistribution(JNIEnv* env, jobject loader, double mu, double beta)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewLaplaceDistribution(env, loader, mu, beta);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JLaplaceDistribution_density(JNIEnv* env, jobject laDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != laDistObj);
	return _jLaDist.FP_density(env, laDistObj, x);
}
jdouble JLaplaceDistribution_logDensity(JNIEnv* env, jobject laDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != laDistObj);
	return _jLaDist.FP_logDensity(env, laDistObj, x);
}
jdouble JLaplaceDistribution_cumulativeProbability(JNIEnv* env, jobject laDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != laDistObj);
	return _jLaDist.FP_cumulativeProbability(env, laDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewLaplaceDistribution(JNIEnv* env, jobject loader, double mu, double beta)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = beta},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,LA_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JLaplaceDistribution_doDensity(JNIEnv* env, jobject laDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, laDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, laDistObj, mid, argValues);
}
static jdouble JLaplaceDistribution_doLogDensity(JNIEnv* env, jobject laDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, laDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, laDistObj, mid, argValues);
}
static jdouble JLaplaceDistribution_doCumulativeProbability(JNIEnv* env, jobject laDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, laDistObj), "cumulativeProbability", "(D)D");
	return JClass_CallDoubleMethodA(env, laDistObj, mid, argValues);
}

