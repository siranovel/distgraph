#ifndef _JJFreeChart_H_
#define _JJFreeChart_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JJFreeChart JJFreeChart;

struct _JJFreeChart
{
	jobject (*FP_getXYPlot)(JNIEnv* env, jobject chart);
	void    (*FP_addSubtitle)(JNIEnv* env, jobject chart, jobject subtitle);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JJFreeChart_getXYPlot(JNIEnv* env, jobject chart);
void JJFreeChart_addSubtitle(JNIEnv* env, jobject chart, jobject subtitle);
#endif
