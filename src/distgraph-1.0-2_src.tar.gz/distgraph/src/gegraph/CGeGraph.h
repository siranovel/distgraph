#ifndef _CGeGraph_H_
#define _CGeGraph_H_

/**************************************/
/* ��¤�����                         */
/**************************************/
typedef struct _CGeGraph CGeGraph;

struct _CGeGraph
{
	void (*FP_createChart)(CGeGraph* pThis);
	void (*FP_writeChartAsJPEG)(CGeGraph* pThis, char* fileName);
};

/**************************************/
/* define���                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �ץ��ȥ��������                   */
/**************************************/
CGeGraph* getGeGraph(char* modPth, double p);
void CGeGraph_ctor(CGeGraph* pThis, char* modPth, double p);
void CGeGraph_dtor(CGeGraph* pThis);
void CGeGraph_createChart(CGeGraph* pThis);
void CGeGraph_writeChartAsJPEG(CGeGraph* pThis, char* fileName);

#endif
