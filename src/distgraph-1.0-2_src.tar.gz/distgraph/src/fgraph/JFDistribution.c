#include <stdio.h>
#include <assert.h>
#include "JFDistribution.h"
#include "JClassLoader.h"


static jobject doNewFDistribution(JNIEnv* env, jobject loader, double nf, double df);
static jdouble JFDistribution_doDensity(JNIEnv* env, jobject fDistObj, jdouble x);
static jdouble JFDistribution_doLogDensity(JNIEnv* env, jobject fDistObj, jdouble x);
static JFDistribution _jFDist = {
	.FP_density = JFDistribution_doDensity,
	.FP_logDensity = JFDistribution_doLogDensity,
};
jobject newFDistribution(JNIEnv* env, jobject loader, double nf, double df)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewFDistribution(env, loader, nf, df);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JFDistribution_density(JNIEnv* env, jobject fDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != fDistObj);
	return _jFDist.FP_density(env, fDistObj, x);
}
jdouble JFDistribution_logDensity(JNIEnv* env, jobject fDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != fDistObj);
	return _jFDist.FP_logDensity(env, fDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewFDistribution(JNIEnv* env, jobject loader, double nf, double df)
{
	jvalue argValues[] = {
		[0] = { .d = nf},
		[1] = { .d = df},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,F_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JFDistribution_doDensity(JNIEnv* env, jobject fDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, fDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, fDistObj, mid, argValues);
}
static jdouble JFDistribution_doLogDensity(JNIEnv* env, jobject fDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, fDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, fDistObj, mid, argValues);
}
