#ifndef _JFDistribution_H_
#define _JFDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JFDistribution JFDistribution;

struct _JFDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject fDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject fDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define F_DIST "org.apache.commons.math3.distribution.FDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newFDistribution(JNIEnv* env, jobject loader, double nf, double df);
jdouble JFDistribution_density(JNIEnv* env, jobject fDistObj, jdouble x);
jdouble JFDistribution_logDensity(JNIEnv* env, jobject fDistObj, jdouble x);
#endif
