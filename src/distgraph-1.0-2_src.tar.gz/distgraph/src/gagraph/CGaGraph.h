#ifndef _CGaGraph_H_
#define _CGaGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CGaGraph CGaGraph;

struct _CGaGraph
{
	void (*FP_createChart)(CGaGraph* pThis);
	void (*FP_writeChartAsJPEG)(CGaGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CGaGraph* getGaGraph(char* modPth, double shape, double scale);
void CGaGraph_ctor(CGaGraph* pThis, char* modPth, double shape, double scale);
void CGaGraph_dtor(CGaGraph* pThis);
void CGaGraph_createChart(CGaGraph* pThis);
void CGaGraph_writeChartAsJPEG(CGaGraph* pThis, char* fileName);
#endif
