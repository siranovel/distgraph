#ifndef _JGammaDistribution_H_
#define _JGammaDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JGammaDistribution JGammaDistribution;

struct _JGammaDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject gaDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject gaDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define GA_DIST "org.apache.commons.math3.distribution.GammaDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newGammaDistribution(JNIEnv* env, jobject loader, double shape, double scale);
jdouble JGammaDistribution_density(JNIEnv* env, jobject gaDistObj, jdouble x);
jdouble JGammaDistribution_logDensity(JNIEnv* env, jobject gaDistObj, jdouble x);

#endif
