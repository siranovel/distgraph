#include <stdio.h>
#include <assert.h>
#include "JGammaDistribution.h"
#include "JClassLoader.h"

static jobject doNewGammaDistribution(JNIEnv* env, jobject loader, double shape, double scale);
static jdouble JGammaDistribution_doDensity(JNIEnv* env, jobject gaDistObj, jdouble x);
static jdouble JGammaDistribution_doLogDensity(JNIEnv* env, jobject gaDistObj, jdouble x);
static JGammaDistribution _jGaDist = {
	.FP_density = JGammaDistribution_doDensity,
	.FP_logDensity = JGammaDistribution_doLogDensity,
};
jobject newGammaDistribution(JNIEnv* env, jobject loader, double shape, double scale)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewGammaDistribution(env, loader, shape, scale);
}

/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JGammaDistribution_density(JNIEnv* env, jobject gaDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != gaDistObj);
	return _jGaDist.FP_density(env, gaDistObj, x);
}
jdouble JGammaDistribution_logDensity(JNIEnv* env, jobject gaDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != gaDistObj);
	return _jGaDist.FP_logDensity(env, gaDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewGammaDistribution(JNIEnv* env, jobject loader, double shape, double scale)
{
	jvalue argValues[] = {
		[0] = { .d = shape},
		[1] = { .d = scale},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,GA_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}

static jdouble JGammaDistribution_doDensity(JNIEnv* env, jobject gaDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, gaDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, gaDistObj, mid, argValues);
}
static jdouble JGammaDistribution_doLogDensity(JNIEnv* env, jobject gaDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, gaDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, gaDistObj, mid, argValues);
}
