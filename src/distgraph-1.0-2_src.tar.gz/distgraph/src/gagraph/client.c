#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CGaGraph.h"

static void usage(char* exeNm);
void gaGraph(CGaGraph* pThis);
int main(int argc, char* argv[])
{
	double shape = 0.0;
	double scale = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &shape);
	sscanf(argv[3], "%lf", &scale);
	
	CGaGraph* pThis = getGaGraph(updModPth, shape, scale);
	
	gaGraph(pThis);
	CGaGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <shape> <scale> \n", exeNm);
}
void gaGraph(CGaGraph* pThis)
{
	CGaGraph_createChart(pThis);
	CGaGraph_writeChartAsJPEG(pThis, "gaGraph.jpg");
}
