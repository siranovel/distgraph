#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CBetaGraph.h"

static void usage(char* exeNm);
void betaGraph(CBetaGraph* pThis);
int main(int argc, char* argv[])
{
	double alpha = 0.0;
	double beta = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &alpha);
	sscanf(argv[3], "%lf", &beta);
	
	CBetaGraph* pThis = getBetaGraph(updModPth, alpha, beta);
	
	betaGraph(pThis);
	CBetaGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <alpha> <beta> \n", exeNm);
}
void betaGraph(CBetaGraph* pThis)
{
	CBetaGraph_createChart(pThis);
	CBetaGraph_writeChartAsJPEG(pThis, "betaGraph.jpg");
}
