#include <stdio.h>
#include <assert.h>
#include "JGamma.h"
#include "JModuleLayer.h"
#include "JClassLoader.h"

static jdouble JGamma_doGamma(JNIEnv* env, jobject loader, jdouble x);
static JGamma _jGamma = {
	.FP_gamma = JGamma_doGamma
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JGamma_gamma(JNIEnv* env, jobject loader, jdouble x)
{
	assert(0 != env);
	assert(0 != loader);
	return _jGamma.FP_gamma(env, loader, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jdouble JGamma_doGamma(JNIEnv* env, jobject loader, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,GAMMA));
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "gamma", "(D)D");
	
	return JClass_CallStaticDoubleMethodA(env, clz, mid, argValues);
}
