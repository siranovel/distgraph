#ifndef _JGamma_H_
#define _JGamma_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JGamma JGamma;

struct _JGamma
{
	jdouble (*FP_gamma)(JNIEnv* env, jobject loader, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define GAMMA "org.apache.commons.math3.special.Gamma"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jdouble JGamma_gamma(JNIEnv* env, jobject loader, jdouble x);
#endif
