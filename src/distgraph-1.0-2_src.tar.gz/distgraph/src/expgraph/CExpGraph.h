#ifndef _CExpGraph_H_
#define _CExpGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CExpGraph CExpGraph;

struct _CExpGraph
{
	void (*FP_createChart)(CExpGraph* pThis);
	void (*FP_writeChartAsJPEG)(CExpGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CExpGraph* getExpGraph(char* modPth, double mean);
void CExpGraph_ctor(CExpGraph* pThis, char* modPth, double mean);
void CExpGraph_dtor(CExpGraph* pThis);
void CExpGraph_createChart(CExpGraph* pThis);
void CExpGraph_writeChartAsJPEG(CExpGraph* pThis, char* fileName);
#endif
