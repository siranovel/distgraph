#ifndef _JBinomialDistribution_H_
#define _JBinomialDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JBinomialDistribution JBinomialDistribution;

struct _JBinomialDistribution
{
	jdouble (*FP_probability)(JNIEnv* env, jobject biDistObj, jint x);
	jdouble (*FP_logProbability)(JNIEnv* env, jobject biDistObj, jint x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define BI_DIST "org.apache.commons.math3.distribution.BinomialDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newBinomialDistribution(JNIEnv* env, jobject loader, jint trials, jdouble p);
jdouble JBinomialDistribution_probability(JNIEnv* env, jobject biDistObj, jint x);
jdouble JBinomialDistribution_logProbability(JNIEnv* env, jobject biDistObj, jint x);

#endif
