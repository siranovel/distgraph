#include <stdio.h>
#include <assert.h>
#include "JLogisticDistribution.h"
#include "JClassLoader.h"


static jobject doNewLogisticDistribution(JNIEnv* env, jobject loader, double mu, double s);
static jdouble JLogisticDistribution_doDensity(JNIEnv* env, jobject logDistObj, jdouble x);
static jdouble JLogisticDistribution_doLogDensity(JNIEnv* env, jobject logDistObj, jdouble x);
static JLogisticDistribution _jLogDist = {
	.FP_density = JLogisticDistribution_doDensity,
	.FP_logDensity = JLogisticDistribution_doLogDensity,
};
jobject newLogisticDistribution(JNIEnv* env, jobject loader, double mu, double s)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewLogisticDistribution(env, loader, mu, s);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JLogisticDistribution_density(JNIEnv* env, jobject logDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != logDistObj);
	return _jLogDist.FP_density(env, logDistObj, x);
}
jdouble JLogisticDistribution_logDensity(JNIEnv* env, jobject logDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != logDistObj);
	return _jLogDist.FP_logDensity(env, logDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewLogisticDistribution(JNIEnv* env, jobject loader, double mu, double s)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = s},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,LOG_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JLogisticDistribution_doDensity(JNIEnv* env, jobject logDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, logDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, logDistObj, mid, argValues);
}
static jdouble JLogisticDistribution_doLogDensity(JNIEnv* env, jobject logDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, logDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, logDistObj, mid, argValues);
}
