#ifndef _CLogGraph_H_
#define _CLogGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CLogGraph CLogGraph;

struct _CLogGraph
{
	void (*FP_createChart)(CLogGraph* pThis);
	void (*FP_writeChartAsJPEG)(CLogGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CLogGraph* getLogGraph(char* modPth, double mu, double s);
void CLogGraph_ctor(CLogGraph* pThis, char* modPth, double mu, double s);
void CLogGraph_dtor(CLogGraph* pThis);
void CLogGraph_createChart(CLogGraph* pThis);
void CLogGraph_writeChartAsJPEG(CLogGraph* pThis, char* fileName);

#endif
