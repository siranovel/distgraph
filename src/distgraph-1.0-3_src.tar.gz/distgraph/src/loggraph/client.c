#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CLogGraph.h"

static void usage(char* exeNm);
void logGraph(CLogGraph* pThis);
int main(int argc, char* argv[])
{
	double mu = 0.0;
	double s = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mu);
	sscanf(argv[3], "%lf", &s);
	
	CLogGraph* pThis = getLogGraph(updModPth, mu, s);
	
	logGraph(pThis);
	CLogGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <mu> <s> \n", exeNm);
}
void logGraph(CLogGraph* pThis)
{
	CLogGraph_createChart(pThis);
	CLogGraph_writeChartAsJPEG(pThis, "logGraph.jpg");
}
