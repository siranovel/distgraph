#ifndef _JLogisticDistribution_H_
#define _JLogisticDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JLogisticDistribution JLogisticDistribution;

struct _JLogisticDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject logDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject logDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define LOG_DIST "org.apache.commons.math3.distribution.LogisticDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newLogisticDistribution(JNIEnv* env, jobject loader, double mu, double s);
jdouble JLogisticDistribution_density(JNIEnv* env, jobject logDistObj, jdouble x);
jdouble JLogisticDistribution_logDensity(JNIEnv* env, jobject logDistObj, jdouble x);

#endif
