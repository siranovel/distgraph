#ifndef _CKsGraph_H_
#define _CKsGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CKsGraph CKsGraph;

struct _CKsGraph
{
	void (*FP_createChart)(CKsGraph* pThis);
	void (*FP_writeChartAsJPEG)(CKsGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CKsGraph* getKsGraph(char* modPth, int n);
void CKsGraph_ctor(CKsGraph* pThis, char* modPth, int n);
void CKsGraph_dtor(CKsGraph* pThis);
void CKsGraph_createChart(CKsGraph* pThis);
void CKsGraph_writeChartAsJPEG(CKsGraph* pThis, char* fileName);

#endif
