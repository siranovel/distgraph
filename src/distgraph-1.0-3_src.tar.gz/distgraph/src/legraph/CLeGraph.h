#ifndef _CLeGraph_H_
#define _CLeGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CLeGraph CLeGraph;

struct _CLeGraph
{
	void (*FP_createChart)(CLeGraph* pThis);
	void (*FP_writeChartAsJPEG)(CLeGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CLeGraph* getLeGraph(char* modPth, double mu, double c);
void CLeGraph_ctor(CLeGraph* pThis, char* modPth, double mu, double c);
void CLeGraph_dtor(CLeGraph* pThis);
void CLeGraph_createChart(CLeGraph* pThis);
void CLeGraph_writeChartAsJPEG(CLeGraph* pThis, char* fileName);

#endif
