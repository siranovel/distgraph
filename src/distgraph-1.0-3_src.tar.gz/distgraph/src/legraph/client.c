#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CLeGraph.h"

static void usage(char* exeNm);
void leGraph(CLeGraph* pThis);
int main(int argc, char* argv[])
{
	double mu = 0.0;
	double c = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mu);
	sscanf(argv[3], "%lf", &c);
	
	CLeGraph* pThis = getLeGraph(updModPth, mu, c);
	
	leGraph(pThis);
	CLeGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <mu> <c> \n", exeNm);
}
void leGraph(CLeGraph* pThis)
{
	CLeGraph_createChart(pThis);
	CLeGraph_writeChartAsJPEG(pThis, "leGraph.jpg");
}
