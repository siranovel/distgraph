#include <stdio.h>
#include <assert.h>
#include "JLevyDistribution.h"
#include "JClassLoader.h"


static jobject doNewLevyDistribution(JNIEnv* env, jobject loader, double mu, double c);
static jdouble JLevyDistribution_doDensity(JNIEnv* env, jobject leDistObj, jdouble x);
static jdouble JLevyDistribution_doLogDensity(JNIEnv* env, jobject leDistObj, jdouble x);
static JLevyDistribution _jLeDist = {
	.FP_density = JLevyDistribution_doDensity,
	.FP_logDensity = JLevyDistribution_doLogDensity,
};
jobject newLevyDistribution(JNIEnv* env, jobject loader, double mu, double c)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewLevyDistribution(env, loader, mu, c);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JLevyDistribution_density(JNIEnv* env, jobject leDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != leDistObj);
	return _jLeDist.FP_density(env, leDistObj, x);
}
jdouble JLevyDistribution_logDensity(JNIEnv* env, jobject leDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != leDistObj);
	return _jLeDist.FP_logDensity(env, leDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewLevyDistribution(JNIEnv* env, jobject loader, double mu, double c)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = c},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,LE_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JLevyDistribution_doDensity(JNIEnv* env, jobject leDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, leDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, leDistObj, mid, argValues);
}
static jdouble JLevyDistribution_doLogDensity(JNIEnv* env, jobject leDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, leDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, leDistObj, mid, argValues);
}
