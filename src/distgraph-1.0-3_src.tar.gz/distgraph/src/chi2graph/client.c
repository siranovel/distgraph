#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CChi2Graph.h"

static void usage(char* exeNm);
void chi2Graph(CChi2Graph* pThis);
int main(int argc, char* argv[])
{
	double df = 0.0;
	
	if (3 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &df);
	
	CChi2Graph* pThis = getChi2Graph(updModPth, df);
	
	chi2Graph(pThis);
	CChi2Graph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <df> \n", exeNm);
}
void chi2Graph(CChi2Graph* pThis)
{
	CChi2Graph_createChart(pThis);
	CChi2Graph_writeChartAsJPEG(pThis, "chi2Graph.jpg");
}
