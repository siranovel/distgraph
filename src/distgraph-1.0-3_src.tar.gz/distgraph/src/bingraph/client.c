#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CBinGraph.h"

static void usage(char* exeNm);
static void binGraph(CBinGraph* pThis);
int main(int argc, char* argv[])
{
	int trials;
	double p;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &trials);
	sscanf(argv[3], "%lf", &p);
	
	CBinGraph* pThis = getBinGraph(updModPth, trials, p);
	
	binGraph(pThis);
	CBinGraph_dtor(pThis);
	
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <trials> <p> \n", exeNm);
}
static void binGraph(CBinGraph* pThis)
{
	CBinGraph_createChart(pThis);
	CBinGraph_writeChartAsJPEG(pThis, "binGraph.jpg");
}
