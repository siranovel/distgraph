#ifndef _CBinGraph_H_
#define _CBinGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CBinGraph CBinGraph;

struct _CBinGraph
{
	void (*FP_createChart)(CBinGraph* pThis);
	void (*FP_writeChartAsJPEG)(CBinGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CBinGraph* getBinGraph(char* modPth, int trials, double p);
void CBinGraph_ctor(CBinGraph* pThis, char* modPth, int trials, double p);
void CBinGraph_dtor(CBinGraph* pThis);
void CBinGraph_createChart(CBinGraph* pThis);
void CBinGraph_writeChartAsJPEG(CBinGraph* pThis, char* fileName);
#endif
