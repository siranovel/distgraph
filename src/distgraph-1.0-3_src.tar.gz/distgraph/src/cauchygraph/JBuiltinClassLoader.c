#include <stdio.h>
#include <assert.h>
#include "JBuiltinClassLoader.h"

static void JBuiltinClassLoader_doLoadModule(JNIEnv* env, jobject loader, jobject mref);
static JBuiltinClassLoader _jBuiltinClassLoader = {
	.FP_loadModule = JBuiltinClassLoader_doLoadModule,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JBuiltinClassLoader_loadModule(JNIEnv* env, jobject loader, jobject mref)
{
	_jBuiltinClassLoader.FP_loadModule(env, loader, mref);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void JBuiltinClassLoader_doLoadModule(JNIEnv* env, jobject loader, jobject mref)
{
	jvalue argValues[] = {
		[0] = { .l = mref},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, loader), "loadModule", "(Ljava/lang/module/ModuleReference;)V");
	JClass_CallVoidMethodA(env, loader, mid, argValues);
}
