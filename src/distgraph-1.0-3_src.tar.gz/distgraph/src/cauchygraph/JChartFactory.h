#ifndef _JChartFactory_H_
#define _JChartFactory_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JChartFactory JChartFactory;

struct _JChartFactory
{
	void (*FP_setChartTheme)(JNIEnv* env, jobject loader);
	jobject (*FP_createXYLineChart)(JNIEnv* env, jobject loader, jstring title, jstring xAxisLabel, jstring yAxisLabel, jobject dataset);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define ChartFactory           "org.jfree.chart.ChartFactory"
#define StandardChartTheme     "org.jfree.chart.StandardChartTheme"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
void JChartFactory_setChartTheme(JNIEnv* env, jobject loader);
jobject JChartFactory_createXYLineChart(JNIEnv* env, jobject loader, jstring title, jstring xAxisLabel, jstring yAxisLabel, jobject dataset);
#endif
