#ifndef _JPaths_H_
#define _JPaths_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JPaths JPaths;

struct _JPaths
{
	jobject (*FP_get)(JNIEnv *env, char* updModPath);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JPaths_get(JNIEnv *env, char* updModPath);
#endif
