#ifndef _CCauchyGraph_H_
#define _CCauchyGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CCauchyGraph CCauchyGraph;

struct _CCauchyGraph
{
	void (*FP_createChart)(CCauchyGraph* pThis);
	void (*FP_writeChartAsJPEG)(CCauchyGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CCauchyGraph* getCauchyGraph(char* modPth, double median, double scale);
void CCauchyGraph_ctor(CCauchyGraph* pThis, char* modPth, double median, double scale);
void CCauchyGraph_dtor(CCauchyGraph* pThis);
void CCauchyGraph_createChart(CCauchyGraph* pThis);
void CCauchyGraph_writeChartAsJPEG(CCauchyGraph* pThis, char* fileName);
#endif
