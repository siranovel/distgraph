#ifndef _JConstantRealDistribution_H_
#define _JConstantRealDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JConstantRealDistribution JConstantRealDistribution;

struct _JConstantRealDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject constRDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject constRDistObj, jdouble x);
	jdouble (*FP_cumulativeProbability)(JNIEnv* env, jobject constRDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define CONSTR_DIST "org.apache.commons.math3.distribution.ConstantRealDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newConstantRealDistribution(JNIEnv* env, jobject loader, double value);
jdouble JConstantRealDistribution_density(JNIEnv* env, jobject constRDistObj, jdouble x);
jdouble JConstantRealDistribution_logDensity(JNIEnv* env, jobject constRDistObj, jdouble x);
jdouble JConstantRealDistribution_cumulativeProbability(JNIEnv* env, jobject constRDistObj, jdouble x);
#endif
