#ifndef _CUniRGraph_H_
#define _CUniRGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CUniRGraph CUniRGraph;

struct _CUniRGraph
{
	void (*FP_createChart)(CUniRGraph* pThis);
	void (*FP_writeChartAsJPEG)(CUniRGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CUniRGraph* getUniRGraph(char* modPth, double low, double up);
void CUniRGraph_ctor(CUniRGraph* pThis, char* modPth, double low, double up);
void CUniRGraph_dtor(CUniRGraph* pThis);
void CUniRGraph_createChart(CUniRGraph* pThis);
void CUniRGraph_writeChartAsJPEG(CUniRGraph* pThis, char* fileName);

#endif
