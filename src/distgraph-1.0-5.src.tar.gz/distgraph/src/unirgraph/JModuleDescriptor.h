#ifndef _JModuleDescriptor_H_
#define _JModuleDescriptor_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JModuleDescriptor JModuleDescriptor;

struct _JModuleDescriptor
{
	jstring (*FP_name)(JNIEnv *env, jobject mdesc);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jstring JModuleDescriptor_name(JNIEnv *env, jobject mdesc);
#endif
