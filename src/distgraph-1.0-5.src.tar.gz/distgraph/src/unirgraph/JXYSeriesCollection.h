#ifndef _JXYSeriesCollection_H_
#define _JXYSeriesCollection_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JXYSeriesCollection JXYSeriesCollection;

struct _JXYSeriesCollection
{
	void (*FP_addSeries)(JNIEnv* env, jobject seriesColl, jobject series);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define XYSeriesCollection     "org.jfree.data.xy.XYSeriesCollection"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newXYSeriesCollection(JNIEnv* env, jobject loader);
void JXYSeriesCollection_addSeries(JNIEnv* env, jobject seriesColl, jobject series);
#endif
