#include <stdio.h>
#include <assert.h>
#include "JJFreeChart.h"

static jobject JJFreeChart_doGetXYPlot(JNIEnv* env, jobject chart);
static void JJFreeChart_doAddSubtitle(JNIEnv* env, jobject chart, jobject subtitle);
static JJFreeChart _jJfreeChart = {
	.FP_getXYPlot = JJFreeChart_doGetXYPlot,
	.FP_addSubtitle = JJFreeChart_doAddSubtitle,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JJFreeChart_getXYPlot(JNIEnv* env, jobject chart)
{
	assert(env != 0);
	assert(chart != 0);
	return _jJfreeChart.FP_getXYPlot(env, chart);
}
void JJFreeChart_addSubtitle(JNIEnv* env, jobject chart, jobject subtitle)
{
	assert(env != 0);
	assert(chart != 0);
	assert(subtitle != 0);
	_jJfreeChart.FP_addSubtitle(env, chart, subtitle);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JJFreeChart_doGetXYPlot(JNIEnv* env, jobject chart)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, chart), "getXYPlot", "()Lorg/jfree/chart/plot/XYPlot;");
	
	return JClass_CallObjectMethodA(env, chart, mid, 0);
}
static void JJFreeChart_doAddSubtitle(JNIEnv* env, jobject chart, jobject subtitle)
{
	jvalue argValues[] = {
		[0] = { .l = subtitle},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, chart), "addSubtitle", "(Lorg/jfree/chart/title/Title;)V");
	JClass_CallVoidMethodA(env, chart, mid, argValues);
}
