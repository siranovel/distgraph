#include <stdio.h>
#include <assert.h>
#include "JUniformRealDistribution.h"
#include "JClassLoader.h"


static jobject doNewUniformRealDistribution(JNIEnv* env, jobject loader, jdouble lower, jdouble upper);
static jdouble JUniformRealDistribution_doDensity(JNIEnv* env, jobject unirDistObj, jdouble x);
static jdouble JUniformRealDistribution_doLogDensity(JNIEnv* env, jobject unirDistObj, jdouble x);
static JUniformRealDistribution _jUniRDist = {
	.FP_density = JUniformRealDistribution_doDensity,
	.FP_logDensity = JUniformRealDistribution_doLogDensity,
};
jobject newUniformRealDistribution(JNIEnv* env, jobject loader, jdouble lower, jdouble upper)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewUniformRealDistribution(env, loader, lower, upper);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JUniformRealDistribution_density(JNIEnv* env, jobject unirDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != unirDistObj);
	return _jUniRDist.FP_density(env, unirDistObj, x);
}
jdouble JUniformRealDistribution_logDensity(JNIEnv* env, jobject unirDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != unirDistObj);
	return _jUniRDist.FP_logDensity(env, unirDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewUniformRealDistribution(JNIEnv* env, jobject loader, jdouble lower, jdouble upper)
{
	jvalue argValues[] = {
		[0] = { .d = lower},
		[1] = { .d = upper},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,UNIR_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JUniformRealDistribution_doDensity(JNIEnv* env, jobject unirDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, unirDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, unirDistObj, mid, argValues);
}
static jdouble JUniformRealDistribution_doLogDensity(JNIEnv* env, jobject unirDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, unirDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, unirDistObj, mid, argValues);
}
