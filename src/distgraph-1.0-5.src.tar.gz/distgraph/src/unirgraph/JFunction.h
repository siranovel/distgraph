#ifndef _JFunction_H_
#define _JFunction_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JFunction JFunction;

struct _JFunction
{
	jobject (*FP_apply)(JNIEnv* env, jobject clf, jstring name);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JFunction_apply(JNIEnv* env, jobject clf, jstring name);
#endif
