#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CUniRGraph.h"

static void usage(char* exeNm);
void unirGraph(CUniRGraph* pThis);
int main(int argc, char* argv[])
{
	double low = 0.0;
	double up = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &low);
	sscanf(argv[3], "%lf", &up);
	
	CUniRGraph* pThis = getUniRGraph(updModPth, low, up);
	
	unirGraph(pThis);
	CUniRGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <low> <up> \n", exeNm);
}
void unirGraph(CUniRGraph* pThis)
{
	CUniRGraph_createChart(pThis);
	CUniRGraph_writeChartAsJPEG(pThis, "unirGraph.jpg");
}
