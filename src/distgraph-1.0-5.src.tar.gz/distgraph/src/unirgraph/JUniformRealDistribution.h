#ifndef _JUniformRealDistribution_H_
#define _JUniformRealDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JUniformRealDistribution JUniformRealDistribution;

struct _JUniformRealDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject unirDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject unirDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define UNIR_DIST "org.apache.commons.math3.distribution.UniformRealDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newUniformRealDistribution(JNIEnv* env, jobject loader, jdouble lower, jdouble upper);
jdouble JUniformRealDistribution_density(JNIEnv* env, jobject unirDistObj, jdouble x);
jdouble JUniformRealDistribution_logDensity(JNIEnv* env, jobject unirDistObj, jdouble x);

#endif
