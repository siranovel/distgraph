#ifndef _JNakagamiDistribution_H_
#define _JNakagamiDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JNakagamiDistribution JNakagamiDistribution;

struct _JNakagamiDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject nkDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject nkDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NK_DIST "org.apache.commons.math3.distribution.NakagamiDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newNakagamiDistribution(JNIEnv* env, jobject loader, jdouble mu, jdouble omega);
jdouble JNakagamiDistribution_density(JNIEnv* env, jobject nkDistObj, jdouble x);
jdouble JNakagamiDistribution_logDensity(JNIEnv* env, jobject nkDistObj, jdouble x);

#endif
