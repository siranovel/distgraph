#include <stdio.h>
#include <assert.h>
#include "JNakagamiDistribution.h"
#include "JClassLoader.h"

static jobject doNewNakagamiDistribution(JNIEnv* env, jobject loader, jdouble mu, jdouble omega);
static jdouble JNakagamiDistribution_doDensity(JNIEnv* env, jobject nkDistObj, jdouble x);
static jdouble JNakagamiDistribution_doLogDensity(JNIEnv* env, jobject nkDistObj, jdouble x);
static JNakagamiDistribution _jNKDist = {
	.FP_density = JNakagamiDistribution_doDensity,
	.FP_logDensity = JNakagamiDistribution_doLogDensity,
};
jobject newNakagamiDistribution(JNIEnv* env, jobject loader, jdouble mu, jdouble omega)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewNakagamiDistribution(env, loader, mu, omega);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JNakagamiDistribution_density(JNIEnv* env, jobject nkDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != nkDistObj);
	return _jNKDist.FP_density(env, nkDistObj, x);
}
jdouble JNakagamiDistribution_logDensity(JNIEnv* env, jobject nkDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != nkDistObj);
	return _jNKDist.FP_logDensity(env, nkDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewNakagamiDistribution(JNIEnv* env, jobject loader, jdouble mu, jdouble omega)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = omega},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,NK_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JNakagamiDistribution_doDensity(JNIEnv* env, jobject nkDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, nkDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, nkDistObj, mid, argValues);
}
static jdouble JNakagamiDistribution_doLogDensity(JNIEnv* env, jobject nkDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, nkDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, nkDistObj, mid, argValues);
}
