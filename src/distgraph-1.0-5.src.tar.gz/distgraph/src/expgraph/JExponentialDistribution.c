#include <stdio.h>
#include <assert.h>
#include "JExponentialDistribution.h"
#include "JClassLoader.h"


static jobject doNewExponentialDistribution(JNIEnv* env, jobject loader, jdouble mean);
static jdouble JExponentialDistribution_doDensity(JNIEnv* env, jobject expDistObj, jdouble x);
static jdouble JExponentialDistribution_doLogDensity(JNIEnv* env, jobject expDistObj, jdouble x);
static JExponentialDistribution _jExpDist = {
	.FP_density = JExponentialDistribution_doDensity,
	.FP_logDensity = JExponentialDistribution_doLogDensity,
};
jobject newExponentialDistribution(JNIEnv* env, jobject loader, jdouble mean)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewExponentialDistribution(env, loader, mean);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JExponentialDistribution_density(JNIEnv* env, jobject expDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != expDistObj);
	return _jExpDist.FP_density(env, expDistObj, x);
}
jdouble JExponentialDistribution_logDensity(JNIEnv* env, jobject expDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != expDistObj);
	return _jExpDist.FP_logDensity(env, expDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewExponentialDistribution(JNIEnv* env, jobject loader, jdouble mean)
{
	jvalue argValues[] = {
		[0] = { .d = mean},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,EXP_DIST));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
static jdouble JExponentialDistribution_doDensity(JNIEnv* env, jobject expDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, expDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, expDistObj, mid, argValues);
}
static jdouble JExponentialDistribution_doLogDensity(JNIEnv* env, jobject expDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, expDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, expDistObj, mid, argValues);
}
