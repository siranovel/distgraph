#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CZipfGraph.h"

static void usage(char* exeNm);
static void zipfGraph(CZipfGraph* pThis);
int main(int argc, char* argv[])
{
	int elms;
	double exponent;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &elms);
	sscanf(argv[3], "%lf", &exponent);
	
	CZipfGraph* pThis = getZipfGraph(updModPth, elms, exponent);
	
	zipfGraph(pThis);
	CZipfGraph_dtor(pThis);
	
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <elms> <exponent> \n", exeNm);
}
static void zipfGraph(CZipfGraph* pThis)
{
	CZipfGraph_createChart(pThis);
	CZipfGraph_writeChartAsJPEG(pThis, "zipfGraph.jpg");
}
