#include <stdio.h>
#include <assert.h>
#include "JZipfDistribution.h"
#include "JClassLoader.h"


static jobject doNewZipfDistribution(JNIEnv* env, jobject loader, jint elms, jdouble exponent);
static jdouble JZipfDistribution_doProbability(JNIEnv* env, jobject zipfDistObj, jint x);
static jdouble JZipfDistribution_doLogProbability(JNIEnv* env, jobject zipfDistObj, jint x);
static JZipfDistribution _jZipfDist = {
	.FP_probability = JZipfDistribution_doProbability,
	.FP_logProbability = JZipfDistribution_doLogProbability,
};
jobject newZipfDistribution(JNIEnv* env, jobject loader, jint elms, jdouble exponent)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewZipfDistribution(env, loader, elms, exponent);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JZipfDistribution_probability(JNIEnv* env, jobject zipfDistObj, jint x)
{
	assert(0 != env);
	assert(0 != zipfDistObj);
	return _jZipfDist.FP_probability(env, zipfDistObj, x);
}
jdouble JZipfDistribution_logProbability(JNIEnv* env, jobject zipfDistObj, jint x)
{
	assert(0 != env);
	assert(0 != zipfDistObj);
	return _jZipfDist.FP_logProbability(env, zipfDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewZipfDistribution(JNIEnv* env, jobject loader, jint elms, jdouble exponent)
{
	jvalue argValues[] = {
		[0] = { .i = elms},
		[1] = { .d = exponent},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,ZIPF_DIST));
	
	return JClass_NewObjectA(env, clz, "(ID)V", argValues);
}
static jdouble JZipfDistribution_doProbability(JNIEnv* env, jobject zipfDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, zipfDistObj), "probability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, zipfDistObj, mid, argValues);
}
static jdouble JZipfDistribution_doLogProbability(JNIEnv* env, jobject zipfDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, zipfDistObj), "logProbability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, zipfDistObj, mid, argValues);
}
