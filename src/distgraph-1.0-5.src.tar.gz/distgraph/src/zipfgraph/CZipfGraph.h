#ifndef _CZipfGraph_H_
#define _CZipfGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CZipfGraph CZipfGraph;

struct _CZipfGraph
{
	void (*FP_createChart)(CZipfGraph* pThis);
	void (*FP_writeChartAsJPEG)(CZipfGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CZipfGraph* getZipfGraph(char* modPth, int elms, double exponent);
void CZipfGraph_ctor(CZipfGraph* pThis, char* modPth, int elms, double exponent);
void CZipfGraph_dtor(CZipfGraph* pThis);
void CZipfGraph_createChart(CZipfGraph* pThis);
void CZipfGraph_writeChartAsJPEG(CZipfGraph* pThis, char* fileName);

#endif
