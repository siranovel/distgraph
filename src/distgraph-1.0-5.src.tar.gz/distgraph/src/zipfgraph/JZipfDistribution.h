#ifndef _JZipfDistribution_H_
#define _JZipfDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JZipfDistribution JZipfDistribution;

struct _JZipfDistribution
{
	jdouble (*FP_probability)(JNIEnv* env, jobject zipfDistObj, jint x);
	jdouble (*FP_logProbability)(JNIEnv* env, jobject zipfDistObj, jint x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define ZIPF_DIST "org.apache.commons.math3.distribution.ZipfDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newZipfDistribution(JNIEnv* env, jobject loader, jint elms, jdouble exponent);
jdouble JZipfDistribution_probability(JNIEnv* env, jobject zipfDistObj, jint x);
jdouble JZipfDistribution_logProbability(JNIEnv* env, jobject zipfDistObj, jint x);

#endif
