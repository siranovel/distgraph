#include <stdio.h>
#include <assert.h>
#include "JGumbelDistribution.h"
#include "JClassLoader.h"


static jobject doNewGumbelDistribution(JNIEnv* env, jobject loader, jdouble mu, jdouble beta);
static jdouble JGumbelDistribution_doDensity(JNIEnv* env, jobject guDistObj, jdouble x);
static jdouble JGumbelDistribution_doLogDensity(JNIEnv* env, jobject guDistObj, jdouble x);
static JGumbelDistribution _jGuDist = {
	.FP_density = JGumbelDistribution_doDensity,
	.FP_logDensity = JGumbelDistribution_doLogDensity,
};
jobject newGumbelDistribution(JNIEnv* env, jobject loader, jdouble mu, jdouble beta)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewGumbelDistribution(env, loader, mu, beta);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JGumbelDistribution_density(JNIEnv* env, jobject guDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != guDistObj);
	return _jGuDist.FP_density(env, guDistObj, x);
}
jdouble JGumbelDistribution_logDensity(JNIEnv* env, jobject guDistObj, jdouble x)
{
	assert(0 != env);
	assert(0 != guDistObj);
	return _jGuDist.FP_logDensity(env, guDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewGumbelDistribution(JNIEnv* env, jobject loader, jdouble mu, jdouble beta)
{
	jvalue argValues[] = {
		[0] = { .d = mu},
		[1] = { .d = beta},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,GU_DIST));
	
	return JClass_NewObjectA(env, clz, "(DD)V", argValues);
}
static jdouble JGumbelDistribution_doDensity(JNIEnv* env, jobject guDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, guDistObj), "density", "(D)D");
	
	return JClass_CallDoubleMethodA(env, guDistObj, mid, argValues);
}
static jdouble JGumbelDistribution_doLogDensity(JNIEnv* env, jobject guDistObj, jdouble x)
{
	jvalue argValues[] = {
		[0] = { .d = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, guDistObj), "logDensity", "(D)D");
	return JClass_CallDoubleMethodA(env, guDistObj, mid, argValues);
}

