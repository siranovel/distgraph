#include <stdio.h>
#include <assert.h>
#include "JBinomialDistribution.h"
#include "JClassLoader.h"

static jobject doNewBinomialDistribution(JNIEnv* env, jobject loader, jint trials, jdouble p);
static jdouble JBinomialDistribution_doProbability(JNIEnv* env, jobject biDistObj, jint x);
static jdouble JBinomialDistribution_doLogProbability(JNIEnv* env, jobject biDistObj, jint x);
static JBinomialDistribution _jBinDist = {
	.FP_probability = JBinomialDistribution_doProbability,
	.FP_logProbability = JBinomialDistribution_doLogProbability,
};
jobject newBinomialDistribution(JNIEnv* env, jobject loader, jint trials, jdouble p)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewBinomialDistribution(env, loader, trials, p);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JBinomialDistribution_probability(JNIEnv* env, jobject biDistObj, jint x)
{
	assert(0 != env);
	assert(0 != biDistObj);
	return _jBinDist.FP_probability(env, biDistObj, x);
}
jdouble JBinomialDistribution_logProbability(JNIEnv* env, jobject biDistObj, jint x)
{
	assert(0 != env);
	assert(0 != biDistObj);
	return _jBinDist.FP_logProbability(env, biDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewBinomialDistribution(JNIEnv* env, jobject loader, jint trials, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .i = trials},
		[1] = { .d = p},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,BI_DIST));
	
	return JClass_NewObjectA(env, clz, "(ID)V", argValues);
}
static jdouble JBinomialDistribution_doProbability(JNIEnv* env, jobject biDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, biDistObj), "probability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, biDistObj, mid, argValues);
}
static jdouble JBinomialDistribution_doLogProbability(JNIEnv* env, jobject biDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, biDistObj), "logProbability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, biDistObj, mid, argValues);
}
