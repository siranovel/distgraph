#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CPasGraph.h"

static void usage(char* exeNm);
static void pasGraph(CPasGraph* pThis);
int main(int argc, char* argv[])
{
	int r;
	double p;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &r);
	sscanf(argv[3], "%lf", &p);
	
	CPasGraph* pThis = getPasGraph(updModPth, r, p);
	
	pasGraph(pThis);
	CPasGraph_dtor(pThis);
	
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <r> <p> \n", exeNm);
}
static void pasGraph(CPasGraph* pThis)
{
	CPasGraph_createChart(pThis);
	CPasGraph_writeChartAsJPEG(pThis, "pasGraph.jpg");
}
