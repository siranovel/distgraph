#include <stdio.h>
#include <assert.h>
#include "JPascalDistribution.h"
#include "JClassLoader.h"

static jobject doNewPascalDistribution(JNIEnv* env, jobject loader, jint r, jdouble p);
static jdouble JPascalDistribution_doProbability(JNIEnv* env, jobject pasDistObj, jint x);
static jdouble JPascalDistribution_doLogProbability(JNIEnv* env, jobject pasDistObj, jint x);
static JPascalDistribution _jPasDist = {
	.FP_probability = JPascalDistribution_doProbability,
	.FP_logProbability = JPascalDistribution_doLogProbability,
};
jobject newPascalDistribution(JNIEnv* env, jobject loader, jint r, jdouble p)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewPascalDistribution(env, loader, r, p);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JPascalDistribution_probability(JNIEnv* env, jobject pasDistObj, jint x)
{
	assert(0 != env);
	assert(0 != pasDistObj);
	return _jPasDist.FP_probability(env, pasDistObj, x);
}
jdouble JPascalDistribution_logProbability(JNIEnv* env, jobject pasDistObj, jint x)
{
	assert(0 != env);
	assert(0 != pasDistObj);
	return _jPasDist.FP_logProbability(env, pasDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewPascalDistribution(JNIEnv* env, jobject loader, jint r, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .i = r},
		[1] = { .d = p},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,PAS_DIST));
	
	return JClass_NewObjectA(env, clz, "(ID)V", argValues);
}
static jdouble JPascalDistribution_doProbability(JNIEnv* env, jobject pasDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, pasDistObj), "probability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, pasDistObj, mid, argValues);
}
static jdouble JPascalDistribution_doLogProbability(JNIEnv* env, jobject pasDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, pasDistObj), "logProbability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, pasDistObj, mid, argValues);
}
