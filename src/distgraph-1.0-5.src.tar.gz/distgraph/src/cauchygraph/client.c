#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CCauchyGraph.h"

static void usage(char* exeNm);
void cauchyGraph(CCauchyGraph* pThis);
int main(int argc, char* argv[])
{
	double median = 0.0;
	double scale = 0.0;
	
	if (4 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &median);
	sscanf(argv[3], "%lf", &scale);
	
	CCauchyGraph* pThis = getCauchyGraph(updModPth, median, scale);
	
	cauchyGraph(pThis);
	CCauchyGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <median> <scale> \n", exeNm);
}
void cauchyGraph(CCauchyGraph* pThis)
{
	CCauchyGraph_createChart(pThis);
	CCauchyGraph_writeChartAsJPEG(pThis, "cauchyGraph.jpg");
}
