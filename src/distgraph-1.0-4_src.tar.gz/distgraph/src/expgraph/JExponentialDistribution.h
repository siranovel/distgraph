#ifndef _JExponentialDistribution_H_
#define _JExponentialDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JExponentialDistribution JExponentialDistribution;

struct _JExponentialDistribution
{
	jdouble (*FP_density)(JNIEnv* env, jobject expDistObj, jdouble x);
	jdouble (*FP_logDensity)(JNIEnv* env, jobject expDistObj, jdouble x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define EXP_DIST "org.apache.commons.math3.distribution.ExponentialDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newExponentialDistribution(JNIEnv* env, jobject loader, jdouble mean);
jdouble JExponentialDistribution_density(JNIEnv* env, jobject expDistObj, jdouble x);
jdouble JExponentialDistribution_logDensity(JNIEnv* env, jobject expDistObj, jdouble x);
#endif
