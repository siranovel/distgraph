#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CExpGraph.h"

static void usage(char* exeNm);
void expGraph(CExpGraph* pThis);
int main(int argc, char* argv[])
{
	double mean = 0.0;
	
	if (3 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%lf", &mean);
	
	CExpGraph* pThis = getExpGraph(updModPth, mean);
	
	expGraph(pThis);
	CExpGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <mean> \n", exeNm);
}
void expGraph(CExpGraph* pThis)
{
	CExpGraph_createChart(pThis);
	CExpGraph_writeChartAsJPEG(pThis, "expGraph.jpg");
}
