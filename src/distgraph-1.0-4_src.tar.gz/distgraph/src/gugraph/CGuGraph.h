#ifndef _CGuGraph_H_
#define _CGuGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CGuGraph CGuGraph;

struct _CGuGraph
{
	void (*FP_createChart)(CGuGraph* pThis);
	void (*FP_writeChartAsJPEG)(CGuGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CGuGraph* getGuGraph(char* modPth, double mu, double beta);
void CGuGraph_ctor(CGuGraph* pThis, char* modPth, double mu, double beta);
void CGuGraph_dtor(CGuGraph* pThis);
void CGuGraph_createChart(CGuGraph* pThis);
void CGuGraph_writeChartAsJPEG(CGuGraph* pThis, char* fileName);
#endif
