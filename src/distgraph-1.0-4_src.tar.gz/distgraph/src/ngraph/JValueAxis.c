#include <stdio.h>
#include <assert.h>
#include "JValueAxis.h"
#include "JClassLoader.h"

static void JValueAxis_doSetLowerBound(JNIEnv* env, jobject axis, double min);
static void JValueAxis_doSetUpperBound(JNIEnv* env, jobject axis, double max);
static void JValueAxis_doSetLowerMargin(JNIEnv* env, jobject axis, double margin);
static void JValueAxis_doSetUpperMargin(JNIEnv* env, jobject axis, double margin);
static void JValueAxis_doSetTickUnit(JNIEnv* env, jobject loader, jobject axis, double size);
static void JValueAxis_doSetTickUnit_1(JNIEnv* env, jobject axis, jobject unit);
static void JValueAxis_doSetNumberFormatOverride(JNIEnv* env, jobject axis);
static void JValueAxis_doSetNumberFormatOverride_1(JNIEnv* env, jobject axis, jobject formatter);
static jobject newNumberTickUnit(JNIEnv* env, jobject loader, double size);
static jobject newDecimalFormat(JNIEnv* env, jstring pattern);
static JValueAxis _jValueAxis = {
	.FP_setLowerBound = JValueAxis_doSetLowerBound,
	.FP_setUpperBound = JValueAxis_doSetUpperBound,
	.FP_setLowerMargin = JValueAxis_doSetLowerMargin,
	.FP_setUpperMargin = JValueAxis_doSetUpperMargin,
	.FP_setTickUnit = JValueAxis_doSetTickUnit,
	.FP_setNumberFormatOverride = JValueAxis_doSetNumberFormatOverride,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JValueAxis_setLowerBound(JNIEnv* env, jobject axis, double min)
{
	assert(env != 0);
	assert(axis != 0);
	_jValueAxis.FP_setLowerBound(env, axis, min);
}
void JValueAxis_setUpperBound(JNIEnv* env, jobject axis, double max)
{
	assert(env != 0);
	assert(axis != 0);
	_jValueAxis.FP_setUpperBound(env, axis, max);
}
void JValueAxis_setLowerMargin(JNIEnv* env, jobject axis, double margin)
{
	assert(env != 0);
	assert(axis != 0);
	_jValueAxis.FP_setLowerMargin(env, axis, margin);
}
void JValueAxis_setUpperMargin(JNIEnv* env, jobject axis, double margin)
{
	assert(env != 0);
	assert(axis != 0);
	_jValueAxis.FP_setUpperMargin(env, axis, margin);
}
void JValueAxis_setTickUnit(JNIEnv* env, jobject loader, jobject axis, double size)
{
	assert(env != 0);
	assert(axis != 0);
	_jValueAxis.FP_setTickUnit(env, loader, axis, size);
}
void JValueAxis_setNumberFormatOverride(JNIEnv* env, jobject axis)
{
	assert(env != 0);
	assert(axis != 0);
	_jValueAxis.FP_setNumberFormatOverride(env, axis);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void JValueAxis_doSetLowerBound(JNIEnv* env, jobject axis, double min)
{
	jvalue argValues[] = {
		[0] = { .d = min},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, axis), "setLowerBound", "(D)V");
	
	JClass_CallVoidMethodA(env, axis, mid, argValues);
}
static void JValueAxis_doSetUpperBound(JNIEnv* env, jobject axis, double max)
{
	jvalue argValues[] = {
		[0] = { .d = max},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, axis), "setUpperBound", "(D)V");
	
	JClass_CallVoidMethodA(env, axis, mid, argValues);
}
static void JValueAxis_doSetLowerMargin(JNIEnv* env, jobject axis, double margin)
{
	jvalue argValues[] = {
		[0] = { .d = margin},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, axis), "setLowerMargin", "(D)V");
	
	JClass_CallVoidMethodA(env, axis, mid, argValues);
}
static void JValueAxis_doSetUpperMargin(JNIEnv* env, jobject axis, double margin)
{
	jvalue argValues[] = {
		[0] = { .d = margin},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, axis), "setUpperMargin", "(D)V");
	
	JClass_CallVoidMethodA(env, axis, mid, argValues);
}
static void JValueAxis_doSetTickUnit(JNIEnv* env, jobject loader, jobject axis, double size)
{
	JValueAxis_doSetTickUnit_1(env, axis, newNumberTickUnit(env, loader, size));
}
static void JValueAxis_doSetTickUnit_1(JNIEnv* env, jobject axis, jobject unit)
{
	jvalue argValues[] = {
		[0] = { .l = unit},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, axis), "setTickUnit", "(Lorg/jfree/chart/axis/NumberTickUnit;)V");
	
	JClass_CallVoidMethodA(env, axis, mid, argValues);
}
static void JValueAxis_doSetNumberFormatOverride(JNIEnv* env, jobject axis)
{
	JValueAxis_doSetNumberFormatOverride_1(env, axis, newDecimalFormat(env, JClass_StringNew(env, "#,##0")));
}
static void JValueAxis_doSetNumberFormatOverride_1(JNIEnv* env, jobject axis, jobject formatter)
{
	jvalue argValues[] = {
		[0] = { .l = formatter},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, axis), "setNumberFormatOverride", "(Ljava/text/NumberFormat;)V");
	
	JClass_CallVoidMethodA(env, axis, mid, argValues);
}
/*
 * NumberTickUnit class
 */
static jobject newNumberTickUnit(JNIEnv* env, jobject loader, double size)
{
	jvalue argValues[] = {
		[0] = { .d = size},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,NumberTickUnit));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
/*
 * DecimalFormat class
 */
static jobject newDecimalFormat(JNIEnv* env, jstring pattern)
{
	jvalue argValues[] = {
		[0] = { .l = pattern},
	};
	jclass clz = JClass_FindClass(env, "java/text/DecimalFormat");
	
	return JClass_NewObjectA(env, clz, "(Ljava/lang/String;)V", argValues);
}
