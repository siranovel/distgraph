#include <stdio.h>
#include <assert.h>
#include "JPlot.h"

static jobject JPloat_doGetRangeAxis(JNIEnv* env, jobject plot);
static jobject JPloat_doGetDomainAxis(JNIEnv* env, jobject plot);
static JPlot _jPlot = {
	.FP_getRangeAxis = JPloat_doGetRangeAxis,
	.FP_getDomainAxis = JPloat_doGetDomainAxis,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JPloat_getRangeAxis(JNIEnv* env, jobject plot)
{
	assert(env != 0);
	assert(plot != 0);
	return _jPlot.FP_getRangeAxis(env, plot);
}
jobject JPloat_getDomainAxis(JNIEnv* env, jobject plot)
{
	assert(env != 0);
	assert(plot != 0);
	return _jPlot.FP_getDomainAxis(env, plot);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JPloat_doGetRangeAxis(JNIEnv* env, jobject plot)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, plot), "getRangeAxis", "()Lorg/jfree/chart/axis/ValueAxis;");
	
	return JClass_CallObjectMethodA(env, plot, mid, 0);
}
static jobject JPloat_doGetDomainAxis(JNIEnv* env, jobject plot)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, plot), "getDomainAxis", "()Lorg/jfree/chart/axis/ValueAxis;");
	
	return JClass_CallObjectMethodA(env, plot, mid, 0);
}
