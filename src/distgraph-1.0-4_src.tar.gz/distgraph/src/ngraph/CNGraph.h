#ifndef _CNGraph_H_
#define _CNGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CNGraph CNGraph;

struct _CNGraph
{
	void (*FP_createChart)(CNGraph* pThis);
	void (*FP_writeChartAsJPEG)(CNGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CNGraph* getNGraph(char* modPth, double mean, double sd);
void CNGraph_ctor(CNGraph* pThis, char* modPth, double mean, double sd);
void CNGraph_dtor(CNGraph* pThis);
void CNGraph_createChart(CNGraph* pThis);
void CNGraph_writeChartAsJPEG(CNGraph* pThis, char* fileName);
#endif
