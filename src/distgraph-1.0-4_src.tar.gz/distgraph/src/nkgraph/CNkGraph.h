#ifndef _CNkGraph_H_
#define _CNkGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CNkGraph CNkGraph;

struct _CNkGraph
{
	void (*FP_createChart)(CNkGraph* pThis);
	void (*FP_writeChartAsJPEG)(CNkGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CNkGraph* getNkGraph(char* modPth, double mu, double omega);
void CNkGraph_ctor(CNkGraph* pThis, char* modPth, double mu, double omega);
void CNkGraph_dtor(CNkGraph* pThis);
void CNkGraph_createChart(CNkGraph* pThis);
void CNkGraph_writeChartAsJPEG(CNkGraph* pThis, char* fileName);
#endif
