#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "CHyGeGraph.h"

static void usage(char* exeNm);
void hygeGraph(CHyGeGraph* pThis);
int main(int argc, char* argv[])
{
	int popSz = 0;
	int nums = 0;
	int smplSz = 0;
	
	if (5 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	sscanf(argv[2], "%d", &popSz);
	sscanf(argv[3], "%d", &nums);
	sscanf(argv[4], "%d", &smplSz);
	
	CHyGeGraph* pThis = getHyGeGraph(updModPth, popSz, nums, smplSz);
	
	hygeGraph(pThis);
	CHyGeGraph_dtor(pThis);
	return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <populationSize> <numberOfSuccesses> <sampleSize>\n", exeNm);
}
void hygeGraph(CHyGeGraph* pThis)
{
	CHyGeGraph_createChart(pThis);
	CHyGeGraph_writeChartAsJPEG(pThis, "hygeGraph.jpg");
}
