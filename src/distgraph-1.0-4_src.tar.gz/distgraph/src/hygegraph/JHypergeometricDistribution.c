#include <stdio.h>
#include <assert.h>
#include "JHypergeometricDistribution.h"
#include "JClassLoader.h"


static jobject doNewHypergeometricDistribution(JNIEnv* env, jobject loader, jint populationSize, jint numberOfSuccesses, jint sampleSize);
static jdouble JHypergeometricDistribution_doProbability(JNIEnv* env, jobject hygeDistObj, jint x);
static jdouble JHypergeometricDistribution_doLogProbability(JNIEnv* env, jobject hygeDistObj, jint x);
static JHypergeometricDistribution _jHyGeDist = {
	.FP_probability = JHypergeometricDistribution_doProbability,
	.FP_logProbability = JHypergeometricDistribution_doLogProbability,
};
jobject newHypergeometricDistribution(JNIEnv* env, jobject loader, jint populationSize, jint numberOfSuccesses, jint sampleSize)
{
	assert(0 != env);
	assert(0 != loader);
	return doNewHypergeometricDistribution(env, loader, populationSize, numberOfSuccesses, sampleSize);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JHypergeometricDistribution_probability(JNIEnv* env, jobject hygeDistObj, jint x)
{
	assert(0 != env);
	assert(0 != hygeDistObj);
	return _jHyGeDist.FP_probability(env, hygeDistObj, x);
}
jdouble JHypergeometricDistribution_logProbability(JNIEnv* env, jobject hygeDistObj, jint x)
{
	assert(0 != env);
	assert(0 != hygeDistObj);
	return _jHyGeDist.FP_logProbability(env, hygeDistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewHypergeometricDistribution(JNIEnv* env, jobject loader, jint populationSize, jint numberOfSuccesses, jint sampleSize)
{
	jvalue argValues[] = {
		[0] = { .i = populationSize},
		[1] = { .i = numberOfSuccesses},
		[2] = { .i = sampleSize},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,HYGE_DIST));
	
	return JClass_NewObjectA(env, clz, "(III)V", argValues);
}
static jdouble JHypergeometricDistribution_doProbability(JNIEnv* env, jobject hygeDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, hygeDistObj), "probability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, hygeDistObj, mid, argValues);
}
static jdouble JHypergeometricDistribution_doLogProbability(JNIEnv* env, jobject hygeDistObj, jint x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, hygeDistObj), "logProbability", "(I)D");
	
	return JClass_CallDoubleMethodA(env, hygeDistObj, mid, argValues);
}
