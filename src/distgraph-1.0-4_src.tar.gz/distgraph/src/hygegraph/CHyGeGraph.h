#ifndef _CHyGeGraph_H_
#define _CHyGeGraph_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CHyGeGraph CHyGeGraph;

struct _CHyGeGraph
{
	void (*FP_createChart)(CHyGeGraph* pThis);
	void (*FP_writeChartAsJPEG)(CHyGeGraph* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define DT  0.001
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CHyGeGraph* getHyGeGraph(char* modPth, int popSz, int nums, int smplSz);
void CHyGeGraph_ctor(CHyGeGraph* pThis, char* modPth, int popSz, int nums, int smplSz);
void CHyGeGraph_dtor(CHyGeGraph* pThis);
void CHyGeGraph_createChart(CHyGeGraph* pThis);
void CHyGeGraph_writeChartAsJPEG(CHyGeGraph* pThis, char* fileName);
#endif
