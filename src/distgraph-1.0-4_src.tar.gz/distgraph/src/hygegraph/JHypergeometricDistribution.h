#ifndef _JHypergeometricDistribution_H_
#define _JHypergeometricDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JHypergeometricDistribution JHypergeometricDistribution;

struct _JHypergeometricDistribution
{
	jdouble (*FP_probability)(JNIEnv* env, jobject hygeDistObj, jint x);
	jdouble (*FP_logProbability)(JNIEnv* env, jobject hygeDistObj, jint x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define HYGE_DIST "org.apache.commons.math3.distribution.HypergeometricDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newHypergeometricDistribution(JNIEnv* env, jobject loader, jint populationSize, jint numberOfSuccesses, jint sampleSize);
jdouble JHypergeometricDistribution_probability(JNIEnv* env, jobject hygeDistObj, jint x);
jdouble JHypergeometricDistribution_logProbability(JNIEnv* env, jobject hygeDistObj, jint x);

#endif
